<?php
include "conf_global.php";
$function   = 1;
$adminindex = "admin/index.php";
$register   = "register.php";
$logout     = "logout.php";
$loginpage  = "login.php";
$loggin     = "functions/loggin.php";
$loginbox   = "functions/loginbox.php";
$menu       = "functions/menu.php";
$skinfooter = "skin/footer.php";
include "functions/cookie.php";
?>