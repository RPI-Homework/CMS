<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 375: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
if (isset($_GET['id']))
{
include $skinheader;
include "../menu.php";
$check = mysql_query($mq)or die("<br>Error Code 376: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 377: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
$check3 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 378: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 == 0)
{
echo "<br>Error Code 87: Group ID does not exist.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
while($gedit = mysql_fetch_array( $check3 ))
{
//-------------------------------
//Root Admin Edit
//-------------------------------
if ($member['gid'] == $ra)
{
echo $skins['contentheader'];
echo "Now editing group " . $gedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $gedit['name'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
if ($gedit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can this group view articles?</td><td>";
if ($gedit['viewarticles'] == 1)
{
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='viewarticles' value='1' />";
echo "No<input type='radio' name='viewarticles' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can send and recieve personal messages?</td><td>";
if ($gedit['canpm'] == 1)
{
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='canpm' value='1' />";
echo "No<input type='radio' name='canpm' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit their profile?</td><td>";
if ($gedit['editprofile'] == 1)
{
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editprofile' value='1' />";
echo "No<input type='radio' name='editprofile' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Is this group a staff member?</td><td>";
if ($gedit['isstaff'] == 1)
{
echo "Yes<input type='radio' name='isstaff' value='1' checked='checked' />";
echo "No<input type='radio' name='isstaff' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='isstaff' value='1' />";
echo "No<input type='radio' name='isstaff' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Is an Administrative Group?</td><td>";
if ($gedit['admin'] == 1)
{
echo "Yes<input type='radio' name='admin' value='1' checked='checked' />";
echo "No<input type='radio' name='admin' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='admin' value='1' />";
echo "No<input type='radio' name='admin' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center>Ignore below if above is no</center></td></tr>";
echo "<tr><td>Can add other administrators?</td><td>";
if ($gedit['addadmin'] == 1)
{
echo "Yes<input type='radio' name='addadmin' value='1' checked='checked' />";
echo "No<input type='radio' name='addadmin' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='addadmin' value='1' />";
echo "No<input type='radio' name='addadmin' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit members?</td><td>";
if ($gedit['caneditmembers'] == 1)
{
echo "Yes<input type='radio' name='caneditmembers' value='1' checked='checked' />";
echo "No<input type='radio' name='caneditmembers' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='caneditmembers' value='1' />";
echo "No<input type='radio' name='caneditmembers' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit articles?</td><td>";
if ($gedit['editarticles'] == 1)
{
echo "Yes<input type='radio' name='editarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='editarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editarticles' value='1' />";
echo "No<input type='radio' name='editarticles' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit homepage?</td><td>";
if ($gedit['edithome'] == 1)
{
echo "Yes<input type='radio' name='edithome' value='1' checked='checked' />";
echo "No<input type='radio' name='edithome' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='edithome' value='1' />";
echo "No<input type='radio' name='edithome' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit member groups?</td><td>";
if ($gedit['editgroups'] == 1)
{
echo "Yes<input type='radio' name='editgroups' value='1' checked='checked' />";
echo "No<input type='radio' name='editgroups' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editgroups' value='1' />";
echo "No<input type='radio' name='editgroups' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit skins?</td><td>";
if ($gedit['editskin'] == 1)
{
echo "Yes<input type='radio' name='editskin' value='1' checked='checked' />";
echo "No<input type='radio' name='editskin' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editskin' value='1' />";
echo "No<input type='radio' name='editskin' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit general settings?</td><td>";
if ($gedit['caneditgeneral'] == 1)
{
echo "Yes<input type='radio' name='caneditgeneral' value='1' checked='checked' />";
echo "No<input type='radio' name='caneditgeneral' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='caneditgeneral' value='1' />";
echo "No<input type='radio' name='caneditgeneral' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can view site logs?</td><td>";
if ($gedit['viewlogs'] == 1)
{
echo "Yes<input type='radio' name='viewlogs' value='1' checked='checked' />";
echo "No<input type='radio' name='viewlogs' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='viewlogs' value='1' />";
echo "No<input type='radio' name='viewlogs' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center><input type='submit' name='submit' value='Update Group' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
else if ($gedit['id'] == $ra)
{
echo "<br>Error Code 88: You cannot edit the Root Administrator group.<br>
<a href='" . $groupsindex . "'>Back</a>";
}
else if ($gedit['id'] == $member['gid'])
{
echo "<br>Error Code 89: You cannot edit your own group.<br>
<a href='" . $groupsindex . "'>Back</a>";
}
else if ($mgroup['addadmin'] == 1)
{
echo $skins['contentheader'];
echo "Now editing group " . $gedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $gedit['name'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
if ($gedit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can this group view articles?</td><td>";
if ($gedit['viewarticles'] == 1)
{
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='viewarticles' value='1' />";
echo "No<input type='radio' name='viewarticles' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can send and recieve personal messages?</td><td>";
if ($gedit['canpm'] == 1)
{
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='canpm' value='1' />";
echo "No<input type='radio' name='canpm' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit their profile?</td><td>";
if ($gedit['editprofile'] == 1)
{
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editprofile' value='1' />";
echo "No<input type='radio' name='editprofile' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Is this group a staff member?</td><td>";
if ($gedit['isstaff'] == 1)
{
echo "Yes<input type='radio' name='isstaff' value='1' checked='checked' />";
echo "No<input type='radio' name='isstaff' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='isstaff' value='1' />";
echo "No<input type='radio' name='isstaff' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Is an Administrative Group?</td><td>";
if ($gedit['admin'] == 1)
{
echo "Yes<input type='radio' name='admin' value='1' checked='checked' />";
echo "No<input type='radio' name='admin' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='admin' value='1' />";
echo "No<input type='radio' name='admin' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center>Ignore below if above is no</center></td></tr>";
if ($mgroup['caneditmembers'] == 1)
{
echo "<tr><td>Can edit members?</td><td>";
if ($gedit['caneditmembers'] == 1)
{
echo "Yes<input type='radio' name='caneditmembers' value='1' checked='checked' />";
echo "No<input type='radio' name='caneditmembers' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='caneditmembers' value='1' />";
echo "No<input type='radio' name='caneditmembers' value='0' checked='checked' /></td></tr>";
}
}
if ($mgroup['editarticles'] == 1)
{
echo "<tr><td>Can edit articles?</td><td>";
if ($gedit['editarticles'] == 1)
{
echo "Yes<input type='radio' name='editarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='editarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editarticles' value='1' />";
echo "No<input type='radio' name='editarticles' value='0' checked='checked' /></td></tr>";
}
}
if ($mgroup['edithome'] == 1)
{
echo "<tr><td>Can edit homepage?</td><td>";
if ($gedit['edithome'] == 1)
{
echo "Yes<input type='radio' name='edithome' value='1' checked='checked' />";
echo "No<input type='radio' name='edithome' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='edithome' value='1' />";
echo "No<input type='radio' name='edithome' value='0' checked='checked' /></td></tr>";
}
}
echo "<tr><td>Can edit member groups?</td><td>";
if ($gedit['editgroups'] == 1)
{
echo "Yes<input type='radio' name='editgroups' value='1' checked='checked' />";
echo "No<input type='radio' name='editgroups' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editgroups' value='1' />";
echo "No<input type='radio' name='editgroups' value='0' checked='checked' /></td></tr>";
}
if ($mgroup['editskin'] == 1)
{
echo "<tr><td>Can edit skins?</td><td>";
if ($gedit['editskin'] == 1)
{
echo "Yes<input type='radio' name='editskin' value='1' checked='checked' />";
echo "No<input type='radio' name='editskin' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editskin' value='1' />";
echo "No<input type='radio' name='editskin' value='0' checked='checked' /></td></tr>";
}
}
if ($mgroup['caneditgeneral'] == 1)
{
echo "<tr><td>Can edit general settings?</td><td>";
if ($gedit['caneditgeneral'] == 1)
{
echo "Yes<input type='radio' name='caneditgeneral' value='1' checked='checked' />";
echo "No<input type='radio' name='caneditgeneral' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='caneditgeneral' value='1' />";
echo "No<input type='radio' name='caneditgeneral' value='0' checked='checked' /></td></tr>";
}
}
if ($mgroup['viewlogs'] == 1)
{
echo "<tr><td>Can view site logs?</td><td>";
if ($gedit['viewlogs'] == 1)
{
echo "Yes<input type='radio' name='viewlogs' value='1' checked='checked' />";
echo "No<input type='radio' name='viewlogs' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='viewlogs' value='1' />";
echo "No<input type='radio' name='viewlogs' value='0' checked='checked' /></td></tr>";
}
}
echo "<tr><td colspan='2'><center><input type='submit' name='submit' value='Update Group' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
else if ($gedit['admin'] == 1)
{
echo "<br>Error Code 90: You cannot edit an Administrator group.<br>
<a href='" . $groupsindex . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Now editing group " . $gedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $gedit['name'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
if ($gedit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can this group view articles?</td><td>";
if ($gedit['viewarticles'] == 1)
{
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='viewarticles' value='1' />";
echo "No<input type='radio' name='viewarticles' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can send and recieve personal messages?</td><td>";
if ($gedit['canpm'] == 1)
{
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='canpm' value='1' />";
echo "No<input type='radio' name='canpm' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit their profile?</td><td>";
if ($gedit['editprofile'] == 1)
{
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editprofile' value='1' />";
echo "No<input type='radio' name='editprofile' value='0' checked='checked' /></td></tr>";
}
}
}
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
}
else if (isset($_POST['name']))
{
$check = mysql_query($mq)or die("<br>Error Code 379: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 380: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
if (!$_POST['name'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 91: No group name entered.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($member['gid'] == $ra)
{
$update = mysql_query("UPDATE `" . $database . "`.`group` SET
`name` = '" . $_POST['name'] . "',
`ban` = " . $_POST['ban'] . ",
`viewarticles` = " . $_POST['viewarticles'] . ",
`canpm` = " . $_POST['canpm'] . ",
`editprofile` = " . $_POST['editprofile'] . ",
`isstaff` = " . $_POST['isstaff'] . ",
`admin` = " . $_POST['admin'] . ",
`addadmin` = " . $_POST['addadmin'] . ",
`caneditmembers` = " . $_POST['caneditmembers'] . ",
`editarticles` = " . $_POST['editarticles'] . ",
`edithome` = " . $_POST['edithome'] . ",
`editgroups` = " . $_POST['editgroups'] . ",
`editskin` = " . $_POST['editskin'] . ",
`caneditgeneral` = " . $_POST['caneditgeneral'] . ",
`viewlogs` = " . $_POST['viewlogs'] . "
WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 381: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
else if ($mgroup['id'] == $_POST['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 92: You cannot edit your own group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else if ($mgroup['addadmin'] == 1)
{
$update = mysql_query("UPDATE `" . $database . "`.`group` SET
`name` = '" . $_POST['name'] . "',
`ban` = " . $_POST['ban'] . ",
`viewarticles` = " . $_POST['viewarticles'] . ",
`canpm` = " . $_POST['canpm'] . ",
`editprofile` = " . $_POST['editprofile'] . ",
`isstaff` = " . $_POST['isstaff'] . ",
`admin` = " . $_POST['admin'] . ",
`editgroups` = " . $_POST['editgroups'] . "
WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 382: Please contact the Root Administrator immediately.<br>" . mysql_error());
if ($mgroup['caneditmembers'] == 1)
{
$updatemem = mysql_query("UPDATE `" . $database . "`.`group` SET `caneditmembers` = " . $_POST['caneditmembers'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 383: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if ($mgroup['viewlogs'] == 1)
{
$updatelog = mysql_query("UPDATE `" . $database . "`.`group` SET `viewlogs` = " . $_POST['viewlogs'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 384: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if ($mgroup['editarticles'] == 1)
{
$updateart = mysql_query("UPDATE `" . $database . "`.`group` SET `editarticles` = " . $_POST['editarticles'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 385: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if ($mgroup['edithome'] == 1)
{
$updatehome = mysql_query("UPDATE `" . $database . "`.`group` SET `edithome` = " . $_POST['edithome'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 386: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if ($mgroup['editskin'] == 1)
{
$updateskin = mysql_query("UPDATE `" . $database . "`.`group` SET `editskin` = " . $_POST['editskin'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 387: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if ($mgroup['caneditgeneral'] == 1)
{
$updategen = mysql_query("UPDATE `" . $database . "`.`group` SET `caneditgeneral` = " . $_POST['caneditgeneral'] . " WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 388: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`group` SET
`name` = '" . $_POST['name'] . "',
`ban` = " . $_POST['ban'] . ",
`viewarticles` = " . $_POST['viewarticles'] . ",
`canpm` = " . $_POST['canpm'] . ",
`editprofile` = " . $_POST['editprofile'] . "
WHERE `group`.`id` = " . $_POST['id'] . " LIMIT 1 ;")or die("<br>Error Code 389: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
header("Location: " . $groupsindex);
}
}
}
}
else
{
header("Location: " . $groupsindex);
}
}
}
}
?>