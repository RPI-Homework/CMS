<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 357: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
if (isset($_GET['add']))
{
include $skinheader;
include "../menu.php";
$check = mysql_query($mq)or die("<br>Error Code 358: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 359: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
$check3 = mysql_query("SELECT * FROM `group` WHERE `name` = '" . $_GET['add'] . "'")or die("<br>Error Code 360: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 != 0)
{
echo "<br>Error Code 76: Group name already exists.<br>
<a href='" . $groupsindex . "'>Back</a>";
}
else
{
//-------------------------------
//Root Admin Edit
//-------------------------------
if ($member['gid'] == $ra)
{
echo $skins['contentheader'];
echo "Adding Group " . $_GET['add'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $_GET['add'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can this group view articles?</td><td>";
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>Is this group a staff member?</td><td>";
echo "Yes<input type='radio' name='isstaff' value='1' />";
echo "No<input type='radio' name='isstaff' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Is an Administrative Group?</td><td>";
echo "Yes<input type='radio' name='admin' value='1' />";
echo "No<input type='radio' name='admin' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>Ignore below if above is no</center></td></tr>";
echo "<tr><td>Can add other administrators?</td><td>";
echo "Yes<input type='radio' name='addadmin' value='1' />";
echo "No<input type='radio' name='addadmin' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit members?</td><td>";
echo "Yes<input type='radio' name='caneditmembers' value='1' />";
echo "No<input type='radio' name='caneditmembers' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit articles?</td><td>";
echo "Yes<input type='radio' name='editarticles' value='1' />";
echo "No<input type='radio' name='editarticles' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit homepage?</td><td>";
echo "Yes<input type='radio' name='edithome' value='1' />";
echo "No<input type='radio' name='edithome' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit member groups?</td><td>";
echo "Yes<input type='radio' name='editgroups' value='1' />";
echo "No<input type='radio' name='editgroups' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit skins?</td><td>";
echo "Yes<input type='radio' name='editskin' value='1' />";
echo "No<input type='radio' name='editskin' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can edit general settings?</td><td>";
echo "Yes<input type='radio' name='caneditgeneral' value='1' />";
echo "No<input type='radio' name='caneditgeneral' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can view site logs?</td><td>";
echo "Yes<input type='radio' name='viewlogs' value='1' />";
echo "No<input type='radio' name='viewlogs' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center><input type='submit' name='submit' value='Add Group' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
else if ($mgroup['addadmin'] == 1)
{
echo $skins['contentheader'];
echo "Adding Group " . $_GET['add'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $_GET['add'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can this group view articles?</td><td>";
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>Is this group a staff member?</td><td>";
echo "Yes<input type='radio' name='isstaff' value='1' />";
echo "No<input type='radio' name='isstaff' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Is an Administrative Group?</td><td>";
echo "Yes<input type='radio' name='admin' value='1' />";
echo "No<input type='radio' name='admin' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>Ignore below if above is no</center></td></tr>";
if ($mgroup['caneditmembers'] == 1)
{
echo "<tr><td>Can edit members?</td><td>";
echo "Yes<input type='radio' name='caneditmembers' value='1' />";
echo "No<input type='radio' name='caneditmembers' value='0' checked='checked' /></td></tr>";
}
if ($mgroup['editarticles'] == 1)
{
echo "<tr><td>Can edit articles?</td><td>";
echo "Yes<input type='radio' name='editarticles' value='1' />";
echo "No<input type='radio' name='editarticles' value='0' checked='checked' /></td></tr>";
}
if ($mgroup['edithome'] == 1)
{
echo "<tr><td>Can edit homepage?</td><td>";
echo "Yes<input type='radio' name='edithome' value='1' />";
echo "No<input type='radio' name='edithome' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit member groups?</td><td>";
echo "Yes<input type='radio' name='editgroups' value='1' />";
echo "No<input type='radio' name='editgroups' value='0' checked='checked' /></td></tr>";
if ($mgroup['editskin'] == 1)
{
echo "<tr><td>Can edit skins?</td><td>";
echo "Yes<input type='radio' name='editskin' value='1' />";
echo "No<input type='radio' name='editskin' value='0' checked='checked' /></td></tr>";
}
if ($mgroup['caneditgeneral'] == 1)
{
echo "<tr><td>Can edit general settings?</td><td>";
echo "Yes<input type='radio' name='caneditgeneral' value='1' />";
echo "No<input type='radio' name='caneditgeneral' value='0' checked='checked' /></td></tr>";
}
if ($mgroup['viewlogs'] == 1)
{
echo "<tr><td>Can view site logs?</td><td>";
echo "Yes<input type='radio' name='viewlogs' value='1' />";
echo "No<input type='radio' name='viewlogs' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center><input type='submit' name='submit' value='Add Group' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
else
{
echo $skins['contentheader'];
echo "Adding Group " . $_GET['add'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Group Name</td><td><input type='text' maxlength='32' name='name' value='" . $_GET['add'] . "' /></td></tr>
<tr><td>Is this group banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Can this group view articles?</td><td>";
echo "Yes<input type='radio' name='viewarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='viewarticles' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td colspan='2'><center><input type='submit' name='submit' value='Add Group' /></center></td></tr></table></form>";
}
}
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
else if (isset($_POST['name']))
{
$check = mysql_query($mq)or die("<br>Error Code 361: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 362: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
if (!$_POST['name'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 77: No group name enetered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if ($member['gid'] == $ra)
{
$add = mysql_query("INSERT INTO `" . $database . "`.`group` (
`id` ,
`name` ,
`admin` ,
`rootadmin` ,
`caneditmembers` ,
`editarticles` ,
`edithome` ,
`addadmin` ,
`editgroups` ,
`editskin` ,
`caneditgeneral` ,
`viewlogs` ,
`ban` ,
`viewarticles` ,
`isstaff` ,
`canpm` ,
`editprofile`
)
VALUES (
NULL , '" . $_POST['name'] . "', '" . $_POST['admin'] . "', '0' , '" . $_POST['caneditmembers'] . "', '" . $_POST['editarticles'] . "', '" . $_POST['edithome'] . "', '" . $_POST['addadmin'] . "', '" . $_POST['editgroups'] . "', '" . $_POST['editskin'] . "', '" . $_POST['caneditgeneral'] . "', '" . $_POST['viewlogs'] . "', '" . $_POST['ban'] . "', '" . $_POST['viewarticles'] . "', '" . $_POST['isstaff'] . "', '" . $_POST['canpm'] . "', '" . $_POST['editprofile'] . "')
")or die("<br>Error Code 363: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
else if ($mgroup['addadmin'] == 1)
{
if ($mgroup['caneditmembers'] == 1)
{
$caneditmembers2 = $_POST['caneditmembers'];
}
else
{
$caneditmembers2 = 0;
}
if ($mgroup['viewlogs'] == 1)
{
$viewlogs2 = $_POST['viewlogs'];
}
else
{
$viewlogs2 = 0;
}
if ($mgroup['editarticles'] == 1)
{
$editarticles2 = $_POST['editarticles'];
}
else
{
$editarticles2 = 0;
}
if ($mgroup['edithome'] == 1)
{
$edithome2 = $_POST['edithome'];
}
else
{
$edithome2 = 0;
}
if ($mgroup['editskin'] == 1)
{
$editskin2 = $_POST['editskin'];
}
else
{
$editskin2 = 0;
}
if ($mgroup['caneditgeneral'] == 1)
{
$caneditgeneral2 = $_POST['caneditgeneral'];
}
else
{
$caneditgeneral2 = 0;
}
$add = mysql_query("
INSERT INTO `" . $database . "`.`group` (
`id` ,
`name` ,
`admin` ,
`rootadmin` ,
`caneditmembers` ,
`editarticles` ,
`edithome` ,
`addadmin` ,
`editgroups` ,
`editskin` ,
`caneditgeneral` ,
`viewlogs` ,
`ban` ,
`viewarticles` ,
`isstaff` ,
`canpm` ,
`editprofile`
)
VALUES (
NULL , '" . $_POST['name'] . "', '" . $_POST['admin'] . "', '0' , '" . $_POST['caneditmembers'] . "', '" . $editarticles2 . "', '" . $edithome2 . "', '0', '" . $_POST['editgroups'] . "', '" . $editskin2 . "', '" . $caneditgeneral2 . "', '" . $viewlogs2 . "', '" . $_POST['ban'] . "', '" . $_POST['viewarticles'] . "', '" . $_POST['isstaff'] . "', '" . $_POST['canpm'] . "', '" . $_POST['editprofile'] . "')
")or die("<br>Error Code 364: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
else
{
$add = mysql_query("INSERT INTO `" . $database . "`.`group` (
`id` ,
`name` ,
`admin` ,
`rootadmin` ,
`caneditmembers` ,
`editarticles` ,
`edithome` ,
`addadmin` ,
`editgroups` ,
`editskin` ,
`caneditgeneral` ,
`viewlogs` ,
`ban` ,
`viewarticles` ,
`isstaff` ,
`canpm` ,
`editprofile`
)
VALUES (
NULL , '" . $_POST['name'] . "', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '" . $_POST['ban'] . "', '" . $_POST['viewarticles'] . "', '0', '" . $_POST['canpm'] . "', '" . $_POST['editprofile'] . "')
")or die("<br>Error Code 365: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
header("Location: " . $groupsindex);
}
}
}
}
else
{
header("Location: " . $groupsindex);
}
}
}
}
?>