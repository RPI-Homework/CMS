<?php

if ($cookie == 1)
{
$check = mysql_query($mq)or die("<br>Error Code 606: Please contact the Root Administrator immediately.<br>");
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 607: Please contact the Root Administrator immediately.<br>");
while($mgroup = mysql_fetch_array( $check2 ))
{
$skincheck = mysql_query($ms)or die("<br>Error Code 608: Please contact the Root Administrator immediately.<br>");
while($skin = mysql_fetch_array( $skincheck ))
{
echo $skin['login'];
echo $skin['prelogin'];
echo "Now Logged into the Admin Console";
echo $skin['prename'];
echo $member['user'];
echo $skin['prelogout'];
echo "[<a href='" . $logout . "'>Logout</a>]";
echo $skin['postlogin'];
echo $skin['menu'];
echo $skin['menutitles'];
echo "General";
echo $skin['postmenu'];
echo $skin['menulinks'];
echo "<a href='" . $index . "'>Admin Console</a>";
echo $skin['betlinks'];
echo "<a href='" . $mdex . "'>Member's Homepage</a>";
if ($mgroup['caneditgeneral'] == 1 OR $member['gid'] == $ra)
{
echo $skin['betlinks'];
echo "<a href='" . $setindex . "'>Global Settings</a>";
echo $skin['betlinks'];
echo "<a href='" . $menuindex . "'>Navigation Links</a>";
}
if ($member['gid'] == 1)
{
echo $skin['betlinks'];
echo "<a href='" . $sysinfo . "'>System Info</a>";
}
echo $skin['postmenulinks'];
if ($mgroup['addadmin'] == 1 OR $member['gid'] == $ra)
if ($mgroup['caneditmembers'] == 1 OR $member['gid'] == $ra)
{
echo $skin['menutitles'];
echo "Member Settings";
echo $skin['postmenu'];
echo $skin['menulinks'];
echo "<a href='" . $addmembersindex . "'>Add a Member</a>";
echo $skin['betlinks'];
echo "<a href='" . $membersindex . "'>Edit a Member</a>";
echo $skin['betlinks'];
echo "<a href='" . $adminsindex . "'>Add an Administrator</a>";
echo $skin['betlinks'];
echo "<a href='" . $adminsindex . "'>Edit an Administrator</a>";
echo $skin['betlinks'];
echo "<a href='" . $listmembersindex . "'>List all Members</a>";
echo $skin['betlinks'];
echo "<a href='" . $delmembersindex . "'>Delete a Member</a>";
echo $skin['betlinks'];
echo "<a href='" . $groupsindex . "'>Add a Member Group</a>";
echo $skin['betlinks'];
echo "<a href='" . $groupsindex . "'>Edit a Member Group</a>";
echo $skin['betlinks'];
echo "<a href='" . $groupsindex . "'>Delete a Member Group</a>";
echo $skin['betlinks'];
echo "<a href='" . $ipbanindex . "'><b>IP Ban</b></a>";
echo $skin['postmenulinks'];
}
if ($mgroup['editarticles'] == 1 OR $member['gid'] == $ra)
if ($mgroup['edithome'] == 1 OR $member['gid'] == $ra)
{
echo $skin['menutitles'];
echo "Content";
echo $skin['postmenu'];
echo $skin['menulinks'];
echo "<a href='" . $addarticleindex . "'>Add an Article</a>";
echo $skin['betlinks'];
echo "<a href='" . $articleindex . "'>Edit an Article</a>";
echo $skin['betlinks'];
echo "<a href='" . $catarticleindex . "'>Article Categories</a>";
echo $skin['betlinks'];
echo "<a href='" . $memarticleindex . "'>View Submitted Articles</a>";
echo $skin['betlinks'];
echo "<a href='" . $delarticleindex . "'>Delete an Article</a>";
echo $skin['betlinks'];
echo "<a href='" . $homeindex . "'>Add a Homepage</a>";
echo $skin['betlinks'];
echo "<a href='" . $homeindex . "'>Edit a Homepage</a>";
echo $skin['betlinks'];
echo "<a href='" . $homeindex . "'>Delete a Homepage</a>";
echo $skin['postmenulinks'];
}
if ($mgroup['editarticles'] == 1 OR $member['gid'] == $ra)
{
echo $skin['menutitles'];
echo "Visual";
echo $skin['postmenu'];
echo $skin['menulinks'];
echo "<a href='" . $skinindex . "'>Add a Skin</a>";
echo $skin['betlinks'];
echo "<a href='" . $skinindex . "'>Edit a Skin</a>";
echo $skin['betlinks'];
echo "<a href='" . $delskinindex . "'>Delete a Skin</a>";
echo $skin['postmenulinks'];
}
if ($member['gid'] == $ra)
{
echo $skin['loginas'];
echo "You are a Root Administrator.";
echo $skin['postloginas'];
}
else
{
echo $skin['loginas'];
echo "You are an Administrator.";
echo $skin['postloginas'];
}
}
}
}
}
?>