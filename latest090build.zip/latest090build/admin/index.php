<?php
include "global.php";
include "cookie.php";
if ($cookie != 1)
{
include "login.php";
}
else
{
if (isset($_POST['adminskin']))
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `adminskin` = '" . $_POST['adminskin'] . "' WHERE `users`.`id` = " . $admin_id . " LIMIT 1")or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
if (isset($_POST['adminnotes']))
{
if (!$_POST['lines'])
{
$lines = 3;
}
else
{
$lines = $_POST['lines'];
}
if (!$_POST['adminnotes'])
{

}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`general` SET `adminnote` = '" . $_POST['adminnotes'] . "' WHERE `general`.`id` = 1 LIMIT 1")or die("<br>Error Code 220: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
}
else
{
$lines = 8;
}
include $skinheader;
include "menu.php";
include $skincontent;
$check = mysql_query($mq)or die("<br>Error Code 221: Please contact the Root Administrator immediately.<br>");
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 222: Please contact the Root Administrator immediately.<br>");
$mgroup = mysql_fetch_array( $check2 );
$skincheck = mysql_query($ms)or die("<br>Error Code 223: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skincheck );
echo $skins['contentheader'];
echo "<div align='right'>Administrator Dashboard </div> ";
echo $skins['postcontentheader'];
$check = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 224: Please contact the Root Administrator immediately.<br>" . mysql_error());
$general = mysql_fetch_array( $check );
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<center>
<textarea rows='" . $lines . "' cols='75' name='adminnotes' style='background-color:transparent'>" . $general['adminnote'] . "</textarea>
<br>Rows<input type='text' name='lines' value='" . $lines . "' size='3' />
<input type='submit' value='Update Notes' />
</center>
</form>";
echo $skins['contenttext'];
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 225: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<table><tr><td valign='top'>Administration Console Theme </td><td> <form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<select name='adminskin' onChange = 'this.form.submit()'>";
while($row = mysql_fetch_assoc($box2))
{
if ($general['adminskin'] == $member['adminskin'] AND $member['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($member['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($general['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></form></td></tr>";
include "mcheck.php";
if ($adaccess == 1)
{
echo "<tr><td valign='top'>Edit An Administrator </td><td> <form action='" . $adminsindex . "' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Search' /></form></td></tr>";
}
if ($maccess == 1)
{
echo "<tr><td valign='top'>Edit Members</td><td><form action='members/index.php' method='get'>
<input type='text' name='user'>
<input type='submit' name='name' value='Search' /></form></td></tr>";
}

if ($aaccess == 1)
{
echo "<tr><td valign='top'>Edit An Article </td><td> <form action='" . $articleindex . "' method='get'>
<input type='text' name='article'>
<input type='submit' name='name' value='Search' /></form></td></tr>";
}
if ($graccess == 1)
{
echo "<tr><td valign='top'>Edit A Member Group</td><td><form action='groups/edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 226: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option selected='selected' disabled='disabled'>Select a Group</option>";
while($row = mysql_fetch_assoc($box))
{
if ($member['gid'] == $ra)
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
else if ($row['id'] == $ra)
{

}
else if ($mgroup['addadmin'] != 1 AND $row['admin'] == 1)
{

}
else if ($row['id'] == $member['gid'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</form></td></tr>";
}
if ($haccess == 1)
{
echo "<tr><td valign='top'>Edit A Homepage</td><td><form action='home/edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Homepage</option>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 227: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['title'];
if ($row['id'] == $general['guesthome'])
{
echo " (Guest)";
}
if ($row['id'] == $general['memberhome'])
{
echo " (Member)";
}
if ($row['id'] == $general['staffhome'])
{
echo " (Staff)";
}
if ($row['id'] == $general['adminhome'])
{
echo " (Admin)";
}
if ($row['id'] == $general['banhome'])
{
echo " (Banned)";
}
echo "</option>";
}
echo "</select></form></td></tr>";
}
if ($saccess = 1)
{
echo "<tr><td valign='top'>Edit Member Skins</td><td><form action='skinedit/medit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 228: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 229: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gen = mysql_fetch_assoc($genset))
{
if ($row['id'] == $gen['skin'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
}
echo "</select></form></td></tr>";
echo "<tr><td valign='top'>Edit Administrative Skin</td><td><form action='skinedit/edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 231: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gen = mysql_fetch_assoc($genset))
{
if ($row['id'] == $gen['adminskin'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
}
echo "</select></form></td></tr>";
}
echo "</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
?>