<?php
include "global.php";
include "cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "gcheck.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
//-------------------------------
//Rest of Page
//-------------------------------
//-----------------
//by username
//-----------------
if (isset($_POST['name']))
{
$quary1 = mysql_query("SELECT * FROM `memberskin` WHERE `id` = " . $_POST['skin'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` = " . $_POST['adminskin'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary3 = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_POST['guesthome'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary4 = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_POST['memberhome'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary5 = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_POST['staffhome'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary6 = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_POST['adminhome'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary7 = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_POST['banhome'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$quary8 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_POST['membergroup'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num1 = mysql_num_rows($quary1);
$num2 = mysql_num_rows($quary2);
$num3 = mysql_num_rows($quary3);
$num4 = mysql_num_rows($quary4);
$num5 = mysql_num_rows($quary5);
$num6 = mysql_num_rows($quary6);
$num7 = mysql_num_rows($quary7);
$num8 = mysql_num_rows($quary8);
if (!$_POST['name'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 6: A site name is required.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else{
if ($_POST['guestarticles'] == 1 OR $_POST['guestarticles'] == 0)
{
if ($num1 != 0 AND $num2 != 0 AND $num3 != 0 AND $num4 != 0 AND $num5 != 0 AND $num6 != 0 AND $num7 != 0 AND $num8 != 0)
{
$mgen = mysql_fetch_array( $quary8 );
if ($mgen['id'] != $ra AND $mgen['admin'] != 1 AND $mgen['isstaff'] != 1)
{
$update = mysql_query("UPDATE `" . $database . "`.`general` SET `name` = '" . $_POST['name'] . "', `skin` = '" . $_POST['skin'] . "', `adminskin` = '" . $_POST['adminskin'] . "', `guesthome` = '" . $_POST['guesthome'] . "', `memberhome` = '" . $_POST['memberhome'] . "', `staffhome` = '" . $_POST['staffhome'] . "', `adminhome` = '" . $_POST['adminhome'] . "',  `banhome` = '" . $_POST['banhome'] . "', `membergroup` = '" . $_POST['membergroup'] . "', `guestarticles` = '" . $_POST['guestarticles'] . "' WHERE `general`.`id` = 1 LIMIT 1")or die("<br>Error Code 220: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $index);
}
else
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 7: The default member group cannot be an Administrator or a Staff Member.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
}
else
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 8: All fields must be filled.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
}
else
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 9: Guest Articles must be 1 or 0.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
}
}
//-----------------
//search bars 0
//-----------------
else
{
include $skinheader;
include "menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 262: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 220: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($genedit = mysql_fetch_array( $genset ))
{
include $skincontent;
echo $skins['contentheader'];
echo "General Settings";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'><table>
<tr><td>Site Name</td><td><input type='text' cols='75' width='200px' style='background: transparent; font-color: white;' name='name' value='" . $genedit['name'] . "'/><br><br></td></tr>
<tr><td>Default Member Skin</td><td>
<select name='skin'>";
$box = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Default Administrative Skin</td><td>
<select name='adminskin'>";
$box = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select><br><br></td></tr>";
echo "<tr><td>Default Guest Homepage</td><td>
<select name='guesthome'>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['guesthome'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['title'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Default Member Homepage</td><td>
<select name='memberhome'>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['memberhome'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['title'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Default Staff Homepage</td><td>
<select name='staffhome'>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['staffhome'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['title'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Default Administrator Homepage</td><td>
<select name='adminhome'>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['adminhome'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['title'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Default Banned Homepage</td><td>
<select name='banhome'>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['banhome'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['title'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select><br><br></td></tr>";
echo "<tr><td>Default Member Group</td><td>
<select name='membergroup'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($genedit['membergroup'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . " (Current)</option>";
}
else if ($row['id'] == $ra OR $row['admin'] == 1 OR $row['isstaff'] == 1)
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select><br><br></td></tr>";
echo "<tr><td>Can guests add articles?</td><td>";
if ($genedit['guestarticles'] == 1)
{
echo "Yes<input type='radio' name='guestarticles' value='1' checked='checked' />";
echo "No<input type='radio' name='guestarticles' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='guestarticles' value='1' />";
echo "No<input type='radio' name='guestarticles' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center><input type='submit' name='update' value='Update Settings' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
}
}
?>