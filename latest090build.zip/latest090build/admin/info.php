<?php
include "global.php";
include "cookie.php";
if ($cookie != 1)
{
include "login.php";
}
else
{
if (isset($_POST['adminskin']))
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `adminskin` = '" . $_POST['adminskin'] . "' WHERE `users`.`id` = " . $admin_id . " LIMIT 1")or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
include $skinheader;
include "menu.php";
include $skincontent;
$check = mysql_query($mq)or die("<br>Error Code 221: Please contact the Root Administrator immediately.<br>");
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 222: Please contact the Root Administrator immediately.<br>");
$mgroup = mysql_fetch_array( $check2 );
$skincheck = mysql_query($ms)or die("<br>Error Code 223: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skincheck );
echo $skins['contentheader'];
echo "<div align='right'>System Information </div> ";
echo $skins['postcontentheader'];
$check = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 224: Please contact the Root Administrator immediately.<br>" . mysql_error());
$general = mysql_fetch_array( $check );
echo "

<b><font face='century gothic' size='3'>System Version</font></b>
<center><b><font face='century gothic' size='2'>Version 0.9</font></b></center><br><br>


<b><font face='century gothic' size='3'>Licensee</font></b>
<center><b><font face='century gothic' size='2'>Todd Young</font></b></center>
<b><font face='century gothic' size='3'>Licensed Website</font></b>
<center><b><font face='century gothic' size='2'>www.GiveMeHelp.net</font></b></center>
<b><font face='century gothic' size='3'>License Key</font></b>
<center><b><font face='century gothic' size='2'>rl2d-23kd-nd2e-2ne3-if93</font></b></center><br><br>

<b><font face='century gothic' size='3'>GiveMeHelp Team</font></b>
<center><b><font face='century gothic' size='2'>Joe Salomon: software Engineer</font></b></center><br>
<center><b><font face='century gothic' size='2'>Todd Young: system designer</font></b></center><br>
<center><b><font face='century gothic' size='2'>The General: Module Engineer</font></b></center><br><br><br>

<center><a href='http://givemehelp.net/download.html'><b><font face='century gothic' size='4'>Check For Updates</font></b></a><b><font face='century gothic' size='4'> | Report an Error  |  Request Assistance</font></b></center><br><br>


";
echo $skins['postcontenttext'];
include $skinfooter;
}
?>