<?php
$database         = "thenexus_test090";
$databaseuser     = "thenexus_test";
$databasepassword = "test123";
$address          = "localhost";

mysql_connect($address, $databaseuser, $databasepassword)or die("<br>Error Code 00: Bad SQL Database name, SQL username, or SQL password supplied.<br>" . mysql_error());
mysql_select_db($database)or die("<br>Error Code 00: Bad SQL database address, SQL username, SQL password supplied, and/or SQL database name supplied.<br>" . mysql_error());
$ra = 1;

?>