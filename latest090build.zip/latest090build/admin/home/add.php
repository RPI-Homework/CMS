<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
if (isset($_POST['aadd']))
{
$addhome = mysql_query("INSERT INTO `" . $database . "`.`homepage` (
`id` ,
`title` ,
`content`
)
VALUES (
NULL , '" . $_POST['title'] . "', '" . $_POST['content'] . "'
)")or die("<br>Error Code 396: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $homeindex);
}
else if (isset($_GET['add']))
{
if (!$_GET['add'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 96: No name entered.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$home = mysql_fetch_array( $check );
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 397: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
echo $skins['contentheader'];
echo "Adding " . $_GET['add'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
Title</td><td>
<input type='text' name='title' value='" . $_GET['add'] . "' /></td><td><input type='submit' name='aadd' value='Add Homepage' /></td></tr>
<tr><td>Content</td><td></td></tr>
<tr><td colspan='3'>
<textarea rows='40' cols='75' name='content'></textarea>
</td></tr>
</table>
</form>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
else
{
header("Location: " . $homeindex);
}
}
}
?>