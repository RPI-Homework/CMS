<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 288: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_GET['add']))
{
include $skincontent;
if (!$_GET['add'])
{
echo "<br>Error Code 25: No username entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `user` LIKE '%" . $_GET['add'] . "%' ORDER BY `user`")or die("<br>Error Code 289: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 26: No usernames contains " . $_GET['add'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
echo $skins['contentheader'];
echo "Usernames that contain " . $_GET['add'] . ".<br>";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>IP Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Edit</center></td>
</tr>";
while ($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 290: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $medit['id'] . "'>Edit</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
}
}
include $skinfooter;
}
else
{
//-------------------------------
//Add Admin
//-------------------------------
include $skincontent;
echo $skins['contentheader'];
echo"Administration";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add an Administrator<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Add' />
</form>";
//-------------------------------
//Edit Admin
//-------------------------------
$check = mysql_query($mq)or die("<br>Error Code 291: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
echo "Edit an Administrator<form action='edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select an Administrator</option>";
if ($member['gid'] == $ra)
{
$add = mysql_query("SELECT * FROM `users` WHERE `gid` = " . $ra . " ORDER BY `user`")or die("<br>Error Code 292: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($editroot = mysql_fetch_assoc($add))
{
echo "<option value='" . $editroot['id'] . "'>" . $editroot['user'] . " (Root)</option>";
}
}
$add2 = mysql_query("SELECT * FROM `group` WHERE `admin` = 1")or die("<br>Error Code 293: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($editadmin = mysql_fetch_assoc($add2))
{
$add3 = mysql_query("SELECT * FROM `users` WHERE `gid` LIKE " . $editadmin['id'] . " ORDER BY `user`")or die("<br>Error Code 294: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($editmember = mysql_fetch_assoc($add3))
{
if ($editmember['gid'] == $ra)
{

}
else if ($editmember['id'] == $member['id'])
{

}
else
{
echo "<option value='" . $editmember['id'] . "'>" . $editmember['user'] . " (Admin)</option>";
}
}
}
$add2 = mysql_query("SELECT * FROM `group` WHERE `isstaff` = 1")or die("<br>Error Code 295: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($editadmin = mysql_fetch_assoc($add2))
{
if ($editadmin['admin'] != 1)
{
$add3 = mysql_query("SELECT * FROM `users` WHERE `gid` LIKE " . $editadmin['id'] . " ORDER BY `user`")or die("<br>Error Code 296: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($editmember = mysql_fetch_assoc($add3))
{
if ($editmember['gid'] == $ra)
{

}
else if ($editmember['id'] == $member['id'])
{

}
else
{
echo "<option value='" . $editmember['id'] . "'>" . $editmember['user'] . " (Staff)</option>";
}
}
}
}
echo "</select></form>";
echo $skins['postcontenttext'];
include $skinfooter;
//-------------------
//End
//-------------------
}
}
}
}
}
?>