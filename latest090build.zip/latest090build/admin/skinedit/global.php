<?php
include "../../conf_global.php";
$logout = "../logout.php";
$index = "../index.php";
$membersindex = "../members/index.php";
$listmembersindex = "../members/listall.php";
$homeindex = "../home/index.php";
$articleindex = "../art/index.php";
$groupsindex = "../groups/index.php";
$adminsindex = "../admins/index.php";
$mdex = "../../index.php";
$skinindex = "index.php";
$setindex = "../general.php";
$menuindex = "../links.php";
$memarticleindex = "../art/member.php";
$delarticleindex = "../art/del.php";
$delgroupsindex = "../groups/del.php";
$delhomeindex = "../home/del.php";
$addmembersindex = "../members/add.php";
$delmembersindex = "../members/del.php";
$ipbanindex = "../members/ban.php";
$delskinindex = "del.php";
$addarticleindex = "../art/add.php";
$catarticleindex = "../art/cat.php";
$skinheader = "../skin/header.php";
$skinmenu = "../skin/menu.php";
$skincontent = "../skin/content.php";
$skinfooter = "../skin/footer.php";
?>