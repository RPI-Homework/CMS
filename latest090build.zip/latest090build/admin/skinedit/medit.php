<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 552: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
if (isset($_POST['author']))
{
if (!$_POST['author'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 146: No author entered.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['skin'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 147: No skin name entered.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 148: Invalid skin ID.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` = " . $_POST['id'])or die("<br>Error Code 553: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 == 0)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 149: Invalid skin ID.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`memberskin` SET
`skin` = '" . $_POST['skin'] . "',
`author` = '" . $_POST['author'] . "',
`header` = '" . $_POST['header'] . "',
`banner` = '" . $_POST['banner'] . "',
`login` = '" . $_POST['login'] . "',
`prelogin` = '" . $_POST['prelogin'] . "',
`prename` = '" . $_POST['prename'] . "',
`prelogout` = '" . $_POST['prelogout'] . "',
`postlogin` = '" . $_POST['postlogin'] . "',
`menu` = '" . $_POST['menu'] . "',
`menutitles` = '" . $_POST['menutitles'] . "',
`menulinks` = '" . $_POST['menulinks'] . "',
`postmenu` = '" . $_POST['postmenu'] . "',
`postmenulinks` = '" . $_POST['postmenulinks'] . "',
`loginas` = '" . $_POST['loginas'] . "',
`eachlink` = '" . $_POST['eachlink'] . "',
`posteachlink` = '" . $_POST['posteachlink'] . "',
`postloginas` = '" . $_POST['postloginas'] . "',
`content` = '" . $_POST['content'] . "',
`contentheader` = '" . $_POST['contentheader'] . "',
`postcontentheader` = '" . $_POST['postcontentheader'] . "',
`contenttext` = '" . $_POST['contenttext'] . "',
`postcontenttext` = '" . $_POST['postcontenttext'] . "',
`copyright` = '" . $_POST['copyright'] . "',
`footer` = '" . $_POST['footer'] . "',
`selectable` = '" . $_POST['selectable'] . "'
WHERE `memberskin`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 554: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $skinindex);
}
}
}
}
}
else if (isset($_GET['id']))
{
if (!$_GET['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 150: Invalid skin ID.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
//-------------------------------
//Rest of Page
//-------------------------------


include $skincontent;
$check3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 555: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
$gencheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 556: Please contact the Root Administrator immediately.<br>" . mysql_error());
if ($num2 == 0)
{
echo "<br>Error Code 151: Invalid skin ID.<br>
<a href='" . $skinindex . "'>Back</a>";
}
else
{
while($sedit = mysql_fetch_array( $check3 ))
{
while($gen = mysql_fetch_array( $gencheck ))
{
//-------------------------------
//Root Admin Edit
//-------------------------------
$check = mysql_query($mq)or die("<br>Error Code 557: Please contact the Root Administrator immediately.<br>");
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 558: Please contact the Root Administrator immediately.<br>");
while($mgroup = mysql_fetch_array( $check2 ))
{
echo $skins['contentheader'];
echo "Now editing skin " . $sedit['skin'] . ".";
echo $skins['postcontentheader'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
echo $skins['contenttext'];
echo "<table><tr><td>Skin Name</td><td><input type='text' name='skin' value='" . $sedit['skin'] . "' /></td></tr>
<tr><td>Author</td><td><input type='text' name='author' value='" . $sedit['author'] . "' /></td></tr></table>";
echo "&lt;html&gt;<br>
&lt;title&gt;<br>
" . $gen['name'] . "<br>
&lt;/title&gt;<br>
&lt;head&gt;";
echo "
<textarea rows='6' cols='75' name='header'>" . $sedit['header'] . "</textarea>
<br>
&lt;/head&gt;<br>
<textarea rows='6' cols='75' name='banner'>" . $sedit['banner'] . "</textarea><br>
------Below is excluded in the log in------
<br>
<textarea rows='6' cols='75' name='login'>" . $sedit['login'] . "</textarea><br>
Log in Box
<br>
<textarea rows='3' cols='75' name='prelogin'>" . $sedit['prelogin'] . "</textarea><br>
Now Logged in as " . $mgroup['name'] . ":
<br>
<textarea rows='3' cols='75' name='prename'>" . $sedit['prename'] . "</textarea><br>
" . $member['user'] . "
<br>
<textarea rows='3' cols='75' name='prelogout'>" . $sedit['prelogout'] . "</textarea><br>
[edit] [inbox] [logout]
<br>
<textarea rows='3' cols='75' name='postlogin'>" . $sedit['postlogin'] . "</textarea><br>
<textarea rows='3' cols='75' name='menu'>" . $sedit['menu'] . "</textarea><br>
Menu Box
<br>
<textarea rows='3' cols='75' name='menutitles'>" . $sedit['menutitles'] . "</textarea><br>
[Menu Title]
<br>
<textarea rows='3' cols='75' name='postmenu'>" . $sedit['postmenu'] . "</textarea><br>
<textarea rows='3' cols='75' name='menulinks'>" . $sedit['menulinks'] . "</textarea><br>
<textarea rows='3' cols='75' name='eachlink'>" . $sedit['eachlink'] . "</textarea><br>
[Menu Links]
<br>
<textarea rows='3' cols='75' name='posteachlink'>" . $sedit['posteachlink'] . "</textarea><br>
<textarea rows='3' cols='75' name='postmenulinks'>" . $sedit['postmenulinks'] . "</textarea><br>
<textarea rows='3' cols='75' name='loginas'>" . $sedit['loginas'] . "</textarea><br>";
if ($member['gid'] == $ra)
{
echo "You are a Root Administrator.";
}
else
{
echo "You are an Administrator.";
}
echo "<br>
<textarea rows='3' cols='75' name='postloginas'>" . $sedit['postloginas'] . "</textarea><br>
------Above is excluded in the log in------
<br>
<textarea rows='6' cols='75' name='content'>" . $sedit['content'] . "</textarea><br>
Content Box
<br>
<textarea rows='3' cols='75' name='contentheader'>" . $sedit['contentheader'] . "</textarea><br>
[Content Header]
<br>
<textarea rows='3' cols='75' name='postcontentheader'>" . $sedit['postcontentheader'] . "</textarea><br>
<textarea rows='3' cols='75' name='contenttext'>" . $sedit['contenttext'] . "</textarea><br>
[Content Body]
<br>
<textarea rows='3' cols='75' name='postcontenttext'>" . $sedit['postcontenttext'] . "</textarea><br>
<textarea rows='6' cols='75' name='copyright'>" . $sedit['copyright'] . "</textarea><br>
[Copyright]
<br>
<textarea rows='6' cols='75' name='footer'>" . $sedit['footer'] . "</textarea><br>
&lt;/html&gt;";

echo "<dl><dt>Is the skin selectable?</dt>";
if ($sedit['selectable'] == 1)
{
echo "<dd>Yes<input type='radio' name='selectable' value='1' checked='checked' />";
echo "No<input type='radio' name='selectable' value='0' /></dd></dl>";
}
else
{
echo "<dd>Yes<input type='radio' name='selectable' value='1' />";
echo "No<input type='radio' name='selectable' value='0' checked='checked' /></dd></dl>";
}
echo"<input type='hidden' name='id' value='" . $_GET['id'] . "' />
<input type='submit' value='Update Skin' />
</form>";

echo $skins['postcontenttext'];
}
}
}
}
}
include $skinfooter;
}
//-------------------
//End
//-------------------
}
else
{
header("Location: " . $skinindex);
}
}
}
else
{
header("Location: " . $index);
}
}
?>