<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 521: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 522: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_GET['aid']))
{
$dskin = mysql_query("SELECT * FROM `adminskin` WHERE id = " . $_GET['aid'])or die("<br>Error Code 523: Please contact the Root Administrator immediately.<br>" . mysql_error());
$sss = mysql_fetch_assoc($dskin);
include $skincontent;
echo $skins['contentheader'];
echo "Deleting " . $sss['skin'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table><tr><td valign='top'>Are you sure?</td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='aaid' value='" . $_GET['aid'] . "' />
<input type='submit' name='aaaaid' value='Yes' />
</form></td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' />
</form></td></tr>
</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['mid']))
{
$dskin = mysql_query("SELECT * FROM `memberskin` WHERE id = " . $_GET['mid'])or die("<br>Error Code 524: Please contact the Root Administrator immediately.<br>" . mysql_error());
$sss = mysql_fetch_assoc($dskin);
include $skincontent;
echo $skins['contentheader'];
echo "Deleting " . $sss['skin'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table><tr><td valign='top'>Are you sure?</td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='mmid' value='" . $_GET['mid'] . "' />
<input type='submit' name='mmmmid' value='Yes' />
</form></td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' />
</form></td></tr>
</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
else
{
if (isset($_POST['aaid']))
{
if ($_POST['aaid'] == $gen['adminskin'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 133: Cannot delete default administrative skin.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `adminskin` = '" . $gen['adminskin'] . "' WHERE `users`.`adminskin` = " . $_POST['aaid'])or die("<br>Error Code 525: Please contact the Root Administrator immediately.<br>" . mysql_error());
$del = mysql_query("DELETE FROM `adminskin` WHERE `adminskin`.`id` = " . $_POST['aaid'] . " LIMIT 1")or die("<br>Error Code 526: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
}
if (isset($_POST['mmid']))
{
if ($_POST['mmid'] == $gen['skin'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 134: Cannot delete default main site skin.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `adminskin` = '" . $gen['skin'] . "' WHERE `users`.`adminskin` = " . $_POST['mmid'])or die("<br>Error Code 527: Please contact the Root Administrator immediately.<br>" . mysql_error());
$del = mysql_query("DELETE FROM `memberskin` WHERE `memberskin`.`id` = " . $_POST['mmid'] . " LIMIT 1")or die("<br>Error Code 528: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
}
include $skincontent;
echo $skins['contentheader'];
echo "Deleting Skins";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Delete an Administrative Skin<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='aid' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 529: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $gen['adminskin'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></form>";
echo "Delete a Member Skin<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='mid' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 530: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 531: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gen = mysql_fetch_assoc($genset))
{
if ($row['id'] == $gen['skin'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
}
echo "</select></form>";
echo $skins['postcontenttext'];
}
}
include $skinfooter;
//-------------------
//End
//-------------------
}
}
?>