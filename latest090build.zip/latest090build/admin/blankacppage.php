<?php
include "global.php";
include "cookie.php";
if ($cookie != 1)
{
include "login.php";
}
else
{
if (isset($_POST['adminskin']))
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `adminskin` = '" . $_POST['adminskin'] . "' WHERE `users`.`id` = " . $admin_id . " LIMIT 1")or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
include $skinheader;
include "menu.php";
include $skincontent;
$check = mysql_query($mq)or die("<br>Error Code 221: Please contact the Root Administrator immediately.<br>");
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 222: Please contact the Root Administrator immediately.<br>");
$mgroup = mysql_fetch_array( $check2 );
$skincheck = mysql_query($ms)or die("<br>Error Code 223: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skincheck );
echo $skins['contentheader'];
echo "<div align='right'>Blank ACP Page </div> ";
echo $skins['postcontentheader'];
$check = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 224: Please contact the Root Administrator immediately.<br>" . mysql_error());
$general = mysql_fetch_array( $check );
echo "

put stuff in here


";
echo $skins['postcontenttext'];
include $skinfooter;
}
?>