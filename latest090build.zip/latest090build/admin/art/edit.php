<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 334: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
if (isset($_GET['id']))
{
if (!$_GET['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 57: No article ID.<br>
<a href='" . $articleindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
$check3 = mysql_query("SELECT * FROM `articles` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 335: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 == 0)
{
echo "<br>Error Code 58: Article ID does not exist.<br>
<a href='" . $articleindex . "'>Back</a>";
}
else
{
$aedit = mysql_fetch_array( $check3 );
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 336: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num3 = mysql_num_rows($check4);
if ($num3 != 0)
{
$cedit = mysql_fetch_array( $check4 );
}
//-------------------------------
//article edits
//-------------------------------
echo $skins['contentheader'];
echo "Now editing " . $aedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 337: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Name</td><td><input type='text' name='name' value='" . $aedit['name'] . "' /></td></tr>
<tr><td>Author</td><td><input type='text' name='author' value='" . $aedit['author'] . "' /></td></tr>
<tr><td>Editor</td><td><input type='text' name='edit' value='" . $aedit['edit'] . "' /></td></tr>
<tr><td colspan='2'>Article<br><textarea rows='10' cols='75' name='article'>" . $aedit['article'] . "</textarea></td></tr>
<input type='hidden' name='id' value='" . $aedit['id'] . "' />
<tr><td>Category</td><td><select name='cat'>
";
$num4 = mysql_num_rows($box);
if ($num4 == 0)
{
echo "<option value='0'>No Categories</option>";
echo "</select></td></tr>";
}
else
{
if ($num3 != 0)
{
echo "<option value='0'>None</option>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'";
if ($aedit['cat'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
}
else
{
echo "<option value='0' selected='selected'>None</option>";
while($row = mysql_fetch_assoc($box))
{ 
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
}
}
echo "<tr><td>Available to Public</td><td>";
if ($aedit['public'] == 1)
{
echo "Yes<input type='radio' name='public' value='1' checked='checked' />";
echo "No<input type='radio' name='public' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='public' value='1' />";
echo "No<input type='radio' name='public' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Member Only Article<br>----If no fill out below</td><td>";
if ($aedit['memberonly'] == 1)
{
echo "Yes<input type='radio' name='memberonly' value='1' checked='checked' />";
echo "No<input type='radio' name='memberonly' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='memberonly' value='1' />";
echo "No<input type='radio' name='memberonly' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Guest Automatically Redirect</td><td>";
if ($aedit['guestredirect'] == 1)
{
echo "Yes<input type='radio' name='guestredirect' value='1' checked='checked' />";
echo "No<input type='radio' name='guestredirect' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='guestredirect' value='1' />";
echo "No<input type='radio' name='guestredirect' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Redirects to</td><td><input type='text' name='redirectto' value='" . $aedit['redirectto'] . "' /></td></tr>
<tr><td colspan='2'>Guest Article<br>----If guest redirect is no<br><textarea rows='10' cols='75' name='garticle'>" . $aedit['guestview'] . "</textarea></td></tr>
<tr><td colspan='2'><input type='submit' name='upart' value='Update Article' /></td></tr>
</table>
</form>";
include $skinfooter;
}
}
}
else if (isset($_POST['name']))
{
if (!$_POST['name'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 59: No article name entered.<br>
<a href='" . $articleindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['author'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 60: No author name entered.<br>
<a href='" . $articleindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['article'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 61: No article text entered.<br>
<a href='" . $articleindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_POST['guestredirect'] == 1 AND !$_POST['redirectto'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 62: A URL must be provided to use guest redirection.<br>
<a href='" . $articleindex . "'>Back</a>";
include $skinfooter;
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`articles` SET
`name` = '" . $_POST['name'] . "',
`author` = '" . $_POST['author'] . "',
`edit` = '" . $_POST['edit'] . "',
`article` = '" . $_POST['article'] . "',
`memberonly` = '" . $_POST['memberonly'] . "',
`guestredirect` = '" . $_POST['guestredirect'] . "',
`redirectto` = '" . $_POST['redirectto'] . "',
`guestview` = '" . $_POST['garticle'] . "',
`public` = '" . $_POST['public'] . "',
`cat` = '" . $_POST['cat'] . "' WHERE `articles`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 338: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $articleindex);
}
}
}
}
}
//-------------------
//End
//-------------------
else
{
header("Location: " . $articleindex);
}
}
}
?>