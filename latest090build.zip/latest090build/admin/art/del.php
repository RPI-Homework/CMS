<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 317: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
//-----------------
//by article name
//-----------------
if (isset($_GET['article']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['article'])
{
echo "<br>Error Code 45: No article name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `name` LIKE '%" . $_GET['article'] . "%' ORDER BY `name`")or die("<br>Error Code 318: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 46: No article names contains " . $_GET['article'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article names that contain " . $_GET['article'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 319: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['author']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['author'])
{
echo "<br>Error Code 47: No author name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `author` LIKE '%" . $_GET['author'] . "%' ORDER BY `name`")or die("<br>Error Code 320: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 48: No article made by author " . $_GET['author'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article made by author " . $_GET['author'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 321: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['editor']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['editor'])
{
echo "<br>Error Code 49: No editor name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `edit` LIKE '%" . $_GET['editor'] . "%' ORDER BY `name`")or die("<br>Error Code 322: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 50: No articles were edited by " . $_GET['editor'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Articles edited by " . $_GET['editor'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 323: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['category']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['category'])
{
echo "<br>Error Code 51: Invalid category ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $_GET['category'])or die("<br>Error Code 324: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
echo "<br>Error Code 52: Invalid category ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$cedit = mysql_fetch_array( $check4 );
$check3 = mysql_query("SELECT * FROM `articles` WHERE `cat` = '" . $_GET['category'] . "' ORDER BY `name`")or die("<br>Error Code 325: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 53: No articles in category " . $cedit['name'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article in category " . $cedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name'] . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
echo "</table>";
}
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['content']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['content'])
{
echo "<br>Error Code 54: No articles text enetered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `article` LIKE '%" . $_GET['article'] . "%' ORDER BY `name`")or die("<br>Error Code 326: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 55: No articles contain that text.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Searching by articles text.";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 327: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['listall']))
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 328: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `name` LIKE '%' ORDER BY `id` DESC")or die("<br>Error Code 329: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
include $skincontent;
echo "<br>Error Code 56: No articles.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
include $skincontent;
echo $skins['contentheader'];
echo "Listing All Articles";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Delete</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 330: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $aedit['id'] . "'>Delete</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['id']))
{
$box = mysql_query("SELECT * FROM `articles` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 331: Please contact the Root Administrator immediately.<br>" . mysql_error());
$row = mysql_fetch_assoc($box);
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Delete" . $row['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table><tr><td valign='top'>Are you sure?</td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='did' value='" . $_GET['id'] . "' />
<input type='submit' name='dddid' value='Yes' /></form></td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' /></form></td></tr></table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_POST['did']))
{
$del = mysql_query("DELETE FROM `articles` WHERE `articles`.`id` = " . $_POST['did'] . " LIMIT 1")or die("<br>Error Code 332: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
//-----------------
//search bars 0
//-----------------
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Articles";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Search by Article Name.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='article'>
<input type='submit' name='name' value='Search' /></form>
Search by Author.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='author'>
<input type='submit' name='maker' value='Search' /></form>
Search by Editor.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='editor'>
<input type='submit' name='edit' value='Search' /></form>
Search by Category.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='category' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 333: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
Search by Article Content. Use % as a wildcard.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='content'>
<input type='submit' name='contains' value='Search' /></form>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "?listall=true'>List all Articles.</a>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
else
{
header("Location: " . $index);
}
}
?>