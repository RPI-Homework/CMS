<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
//Start 2

//-----------------
// 2
//-----------------
if (isset($_GET['acat']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['acat'])
{
echo "<br>Error Code 40: No category name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$skincheck = mysql_query($ms)or die("<br>Error Code 301: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo $skins['contentheader'];
echo "Adding Category " . $_GET['acat'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
Name</td><td><input type='text' name='aoname' value='" . $_GET['acat'] ."'/></td></tr>
<tr><td>Order</td><td><input type='text' name='aoorder' maxlength='2' size='3'/></td></tr>
<tr><td colspan='2'><input type='submit' name='aoadd' value='Add Category'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else if (isset($_POST['aoadd']))
{
if (!$_POST['aoname'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 41: No category name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$addcat = mysql_query("INSERT INTO `" . $database . "`.`acat` (`id` , `name` , `order`)
VALUES (NULL , '" . $_POST['aoname'] . "', '" . $_POST['aoorder'] . "')")or die("<br>Error Code 302: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
}
//-----------------
// 2
//-----------------

//-----------------
// 2
//-----------------
else if (isset($_GET['ecat']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 303: Please contact the Root Administrator immediately.<br>");
$catcheck = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $_GET['ecat'])or die("<br>Error Code 304: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
echo "<br>Error Code 42: Category ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($cat = mysql_fetch_array( $catcheck ))
{
echo $skins['contentheader'];
echo "Editing Category " . $cat['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
<input type='hidden' name='ecid' value='" . $_GET['ecat'] ."'/>
Name</td><td><input type='text' name='ecname' value='" . $cat['name'] ."'/></td></tr>
<tr><td>Order</td><td><input type='text' name='ecorder' value='" . $cat['order'] ."' maxlength='2' size='3'/></td></tr>
<tr><td><input type='submit' name='ecedit' value='Edit Category'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['ecedit']))
{
if (!$_POST['ecname'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 43: No category name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$upcat = mysql_query("UPDATE `" . $database . "`.`acat` SET
`name` = '" . $_POST['ecname'] . "',
`order` = '" . $_POST['ecorder'] . "' WHERE `acat`.`id` = " . $_POST['ecid'] . " LIMIT 1")or die("<br>Error Code 305: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
}
//-----------------
// 2
//-----------------

//-----------------
// 2
//-----------------
else if (isset($_GET['ocat']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 306: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skincheck );
echo $skins['contentheader'];
echo "Ordering Categories";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 307: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<table>";
while($row = mysql_fetch_assoc($box))
{
echo "<tr><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'></td><td>" . $row['name'] . "</td><td><table><input type='hidden' name='ocid' value='" . $row['id'] . "'><input type='text' name='ocupdate' value='" . $row['order'] . "' maxlength='2' size='3'/></table></td><td><table><input type='submit' name='ocorder' value='Edit'></table></form></td></tr>";
}
echo "<tr><td colspan='4'><table><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='Finish'/></form></table></td></tr>
</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_POST['ocorder']))
{
$ordercat = mysql_query("UPDATE `" . $database . "`.`acat` SET `order` = '" . $_POST['ocupdate'] . "' WHERE `acat`.`id` = " . $_POST['ocid'] . " LIMIT 1")or die("<br>Error Code 308: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF'] . "?ocat=true");
}
//-----------------
// 2
//-----------------

//-----------------
// 2
//-----------------
else if (isset($_GET['dcat']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 309: Please contact the Root Administrator immediately.<br>");
$catcheck = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $_GET['dcat'])or die("<br>Error Code 310: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
echo "<br>Error Code 44: Category ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($cat = mysql_fetch_array( $catcheck ))
{
echo $skins['contentheader'];
echo "Deleting Category " . $cat['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td valign='top'>
<input type='hidden' name='dcid' value='" . $_GET['dcat'] ."'/>
Category for Sub-Links</td><td colspan='2'>
<select name='dccat'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 311: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $cat['id'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>
<tr><td valign='top'>Are you sure?</td><td>
<input type='submit' name='dcdel' value='Yes'/>
</form>
</td><td>
<table>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No'/>
</form>
</table>
</td></tr></table>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['dcdel']))
{
$uplink = mysql_query("UPDATE `" . $database . "`.`articles` SET `cat` = '" . $_POST['dccat'] . "' WHERE `articles`.`cat` = " . $_POST['dcid'])or die("<br>Error Code 312: Please contact the Root Administrator immediately.<br>");
$delcar = mysql_query("DELETE FROM `acat` WHERE `acat`.`id` = " . $_POST['dcid'] . " LIMIT 1")or die("<br>Error Code 313: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
//-----------------
// 2
//-----------------
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 314: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo $skins['contentheader'];
echo "Categories";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add a Category<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='acat'/><input type='submit' name='add' value='Add Category'/>
</form>
Edit a Category
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='ecat' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 315: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
Order Categories<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='submit' name='ocat' value='Order Categories'/>
</form>Delete a Category
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='dcat' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 316: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>";
echo $skins['postcontenttext'];
}
include $skinfooter;
}
//End 2
}
}
?>