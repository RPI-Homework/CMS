<?php
if ($cookie == 1)
{
$check = mysql_query($mq)or die("<br>Error Code 611: Please contact the Root Administrator immediately.<br>");
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 612: Please contact the Root Administrator immediately.<br>");
while($mgroup = mysql_fetch_array( $check2 ))
{
if ($mgroup['editarticles'] == 1 OR $member['gid'] == $ra)
{
$access = 1;
}
else
{
header("Location: " . $index);
}
}
}
}
?>