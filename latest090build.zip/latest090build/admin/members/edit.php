<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{

$skinscheck = mysql_query($ms)or die("<br>Error Code 459: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$check = mysql_query($mq)or die("<br>Error Code 460: Please contact the Root Administrator immediately.<br>" . mysql_error());
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 461: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_POST['Update']))
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_POST['id'])or die("<br>Error Code 462: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
$medit = mysql_fetch_array( $check3 );
if (!$_POST['group'])
{}
else
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_POST['group'])or die("<br>Error Code 463: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gedit = mysql_fetch_array( $check4 );
}
$check5 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 464: Please contact the Root Administrator immediately.<br>" . mysql_error());
$extra = mysql_fetch_array( $check5 );
if ($member['gid'] == $ra)
{
if (!$_POST['password'])
{

}
else
{
$uppass = mysql_query("UPDATE `" . $database . "`.`users` SET
`password` = '" . md5($_POST['password']) . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 465: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['name'])
{

}
else
{
$upuser = mysql_query("UPDATE `" . $database . "`.`users` SET
`user` = '" . $_POST['name'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 466: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['email'])
{

}
else
{
$upmail = mysql_query("UPDATE `" . $database . "`.`users` SET
`email` = '" . $_POST['email'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 467: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
$upmem = mysql_query("UPDATE `" . $database . "`.`users` SET
`gid` = '" . $_POST['group'] . "',
`ban` = '" . $_POST['ban'] . "',
`adminskin` = '" . $_POST['adminskin'] . "',
`skin` = '" . $_POST['skin'] . "',
`gender` = '" . $_POST['gender'] . "',
`canpm` = '" . $_POST['canpm'] . "',
`editprofile` = '" . $_POST['editprofile'] . "',
`aim` = '" . $_POST['aim'] . "',
`msn` = '" . $_POST['msn'] . "',
`yim` = '" . $_POST['yim'] . "',
`icq` = '" . $_POST['icq'] . "',
`avatar` = '" . $_POST['avatar'] . "',
`signature` = '" . $_POST['signature'] . "',
`interests` = '" . $_POST['interests'] . "',
`referal` = '" . $_POST['referal'] . "',
`birthday` = '" . $_POST['birthday'] . "',
`url` = '" . $_POST['url'] . "',
`location` = '" . $_POST['location'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 468: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
else if ($medit['gid'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 115: You cannot edit Root Administrators.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else if ($gedit['id'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 116: You cannot add Root Administrators.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else if ($medit['id'] == $member['id'])
{
if (!$_POST['password'])
{

}
else
{
$uppass = mysql_query("UPDATE `" . $database . "`.`users` SET
`password` = '" . md5($_POST['password']) . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 469: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['name'])
{

}
else
{
$upuser = mysql_query("UPDATE `" . $database . "`.`users` SET
`user` = '" . $_POST['name'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 470: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['email'])
{

}
else
{
$upmail = mysql_query("UPDATE `" . $database . "`.`users` SET
`email` = '" . $_POST['email'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 471: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
$upmem = mysql_query("UPDATE `" . $database . "`.`users` SET
`ban` = '" . $_POST['ban'] . "',
`adminskin` = '" . $_POST['adminskin'] . "',
`skin` = '" . $_POST['skin'] . "',
`gender` = '" . $_POST['gender'] . "',
`canpm` = '" . $_POST['canpm'] . "',
`editprofile` = '" . $_POST['editprofile'] . "',
`aim` = '" . $_POST['aim'] . "',
`msn` = '" . $_POST['msn'] . "',
`yim` = '" . $_POST['yim'] . "',
`icq` = '" . $_POST['icq'] . "',
`avatar` = '" . $_POST['avatar'] . "',
`signature` = '" . $_POST['signature'] . "',
`interests` = '" . $_POST['interests'] . "',
`referal` = '" . $_POST['referal'] . "',
`birthday` = '" . $_POST['birthday'] . "',
`url` = '" . $_POST['url'] . "',
`location` = '" . $_POST['location'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 472: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
else if ($mgroup['addadmin'] == 1)
{
if (!$_POST['password'])
{

}
else
{
$uppass = mysql_query("UPDATE `" . $database . "`.`users` SET
`password` = '" . md5($_POST['password']) . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 473: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['name'])
{

}
else
{
$upuser = mysql_query("UPDATE `" . $database . "`.`users` SET
`user` = '" . $_POST['name'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 474: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['email'])
{

}
else
{
$upmail = mysql_query("UPDATE `" . $database . "`.`users` SET
`email` = '" . $_POST['email'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 475: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
$upmem = mysql_query("UPDATE `" . $database . "`.`users` SET
`gid` = '" . $_POST['group'] . "',
`ban` = '" . $_POST['ban'] . "',
`adminskin` = '" . $_POST['adminskin'] . "',
`skin` = '" . $_POST['skin'] . "',
`gender` = '" . $_POST['gender'] . "',
`canpm` = '" . $_POST['canpm'] . "',
`editprofile` = '" . $_POST['editprofile'] . "',
`aim` = '" . $_POST['aim'] . "',
`msn` = '" . $_POST['msn'] . "',
`yim` = '" . $_POST['yim'] . "',
`icq` = '" . $_POST['icq'] . "',
`avatar` = '" . $_POST['avatar'] . "',
`signature` = '" . $_POST['signature'] . "',
`interests` = '" . $_POST['interests'] . "',
`referal` = '" . $_POST['referal'] . "',
`birthday` = '" . $_POST['birthday'] . "',
`url` = '" . $_POST['url'] . "',
`location` = '" . $_POST['location'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 476: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
else if ($gedit['admin'] == 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 117: You cannot edit Administrators.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else if ($extra['admin'] == 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 118: You cannot add Administrators.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{

if (!$_POST['password'])
{

}
else
{
$uppass = mysql_query("UPDATE `" . $database . "`.`users` SET
`password` = '" . md5($_POST['password']) . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 477: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['name'])
{

}
else
{
$upuser = mysql_query("UPDATE `" . $database . "`.`users` SET
`user` = '" . $_POST['name'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 478: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
if (!$_POST['email'])
{

}
else
{
$upmail = mysql_query("UPDATE `" . $database . "`.`users` SET
`email` = '" . $_POST['email'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 479: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
$upmem = mysql_query("UPDATE `" . $database . "`.`users` SET
`gid` = '" . $_POST['group'] . "',
`ban` = '" . $_POST['ban'] . "',
`adminskin` = '" . $_POST['adminskin'] . "',
`skin` = '" . $_POST['skin'] . "',
`gender` = '" . $_POST['gender'] . "',
`canpm` = '" . $_POST['canpm'] . "',
`editprofile` = '" . $_POST['editprofile'] . "',
`aim` = '" . $_POST['aim'] . "',
`msn` = '" . $_POST['msn'] . "',
`yim` = '" . $_POST['yim'] . "',
`icq` = '" . $_POST['icq'] . "',
`avatar` = '" . $_POST['avatar'] . "',
`signature` = '" . $_POST['signature'] . "',
`interests` = '" . $_POST['interests'] . "',
`referal` = '" . $_POST['referal'] . "',
`birthday` = '" . $_POST['birthday'] . "',
`url` = '" . $_POST['url'] . "',
`location` = '" . $_POST['location'] . "'
WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1")or die("<br>Error Code 480: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
}
else if (isset($_GET['id']))
{
if (!$_GET['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 119: Invalid member ID.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 481: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$check = mysql_query($mq)or die("<br>Error Code 482: Please contact the Root Administrator immediately.<br>" . mysql_error());
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 483: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 484: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
$medit = mysql_fetch_array( $check3 );
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 485: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gedit = mysql_fetch_array( $check4 );
//-------------------------------
//Admin no edit Root Admin
//-------------------------------
if ($medit['gid'] == $ra AND $member['gid'] != $ra)
{
echo "<br>Error Code 120: You cannot edit Root Administrators.<br>";
echo "<a href='" . $membersindex . "'>Back</a>";
}
//-------------------------------
//Global Root admin edits
//-------------------------------
else if ($member['gid'] == $ra)
{
echo $skins['contentheader'];
echo "Now editing " . $medit['user'] . ".";
echo $skins['postcontentheader'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 486: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 487: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 488: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 489: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />
<tr><td>Group</td><td><select name='group'>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'";
if ($medit['gid'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $medit['adminskin'] AND $medit['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($medit['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($gen['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $medit['skin'] AND $medit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($medit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
if ($medit['gender'] == 1)
{
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
}
else
{
echo "Male<input type='radio' name='gender' value='1' />";
echo "Female<input type='radio' name='gender' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can send and recieve personal messages?</td><td>";
if ($medit['canpm'] == 1)
{
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='canpm' value='1' />";
echo "No<input type='radio' name='canpm' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit their own profile?</td><td>";
if ($medit['editprofile'] == 1)
{
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editprofile' value='1' />";
echo "No<input type='radio' name='editprofile' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
if ($medit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Update' /></center></td></tr></table></form>";
}
//-------------------------------
//Admins editing admins
//-------------------------------
else if ($mgroup['addadmin'] == 1)
{
echo $skins['contentheader'];
echo "Now editing " . $medit['user'] . ".";
echo $skins['postcontentheader'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 490: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 491: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 492: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 494: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />";
if ($medit['id'] != $member['id'])
{
echo "<tr><td>Group</td><td><select name='group'>";
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $ra)
{

}
else
{
echo "<option value='" . $row['id'] . "'";
}
if ($gen['membergroup'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
}
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $medit['adminskin'] AND $medit['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($medit['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($gen['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $medit['skin'] AND $medit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($medit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their own profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Update' /></center></td></tr></table></form>";
}

//-------------------------------
//Other admin edits
//-------------------------------
else if ($gedit['admin'] == 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 121: You cannot edit Administrators.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
echo $skins['contentheader'];
echo "Now editing " . $medit['user'] . ".";
echo $skins['postcontentheader'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
echo "<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>
<input type='hidden' name='id' value='" . $_GET['id'] . "' />";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 495: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 496: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 497: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 498: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
if ($medit['id'] != $member['id'])
{
echo "<tr><td>Group</td><td><select name='group'>";
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $ra OR $row['admin'] == 1)
{

}
else
{
echo "<option value='" . $row['id'] . "'";
}
if ($gen['membergroup'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
}
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $medit['adminskin'] AND $row['id'] == $medit['adminskin'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 499: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $medit['skin'] AND $row['id'] == $medit['skin'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else if ($medit['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Current)</option>";
}
else if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
if ($medit['gender'] == 1)
{
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
}
else
{
echo "Male<input type='radio' name='gender' value='1' />";
echo "Female<input type='radio' name='gender' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can send and recieve personal messages?</td><td>";
if ($medit['canpm'] == 1)
{
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='canpm' value='1' />";
echo "No<input type='radio' name='canpm' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>Can edit their own profile?</td><td>";
if ($medit['editprofile'] == 1)
{
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='editprofile' value='1' />";
echo "No<input type='radio' name='editprofile' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
if ($medit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' /></td></tr>";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
}
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Update' /></center></td></tr></table></form>";
}
include $skinfooter;
}
}
else
{
header("Location: " . $membersindex);
}
}
//--------------------
//Submitted edit
//--------------------
//-------------------
//End
//-------------------
}
?>