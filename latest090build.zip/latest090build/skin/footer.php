<?php
echo $skin['copyright'];
echo "<font face='century gothic' size='1'> &copy; 2007 <a href='http://computingonlinehelp.com/'>GiveMeHelp.net</a></font>";
echo $skin['footer'];
echo "</html>";
?>