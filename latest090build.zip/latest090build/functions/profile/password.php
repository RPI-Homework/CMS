<?php

if ($function == 1)

{

if (!$member['id'])

{

header("Location: " . $_SERVER['PHP_SELF']);

}

else
{
$old = md5($_POST['opassword']);
if ($old == $member['password'])
{
$new = md5($_POST['password']);
$upmem = mysql_query("UPDATE `" . $database . "`.`users` SET

`password` = '" . $new . "'

WHERE `users`.`id` = " . $member['id'] . " LIMIT 1");
header("Location: " . $_SERVER['PHP_SELF']);
}
}
}

?>