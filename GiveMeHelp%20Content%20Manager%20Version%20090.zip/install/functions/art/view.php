<?php
if ($function == 1)
{
if (!$_GET['id'])
{
echo "<br>No article ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
//-------------------------------
//Rest of Page
//-------------------------------
$check3 = mysql_query("SELECT * FROM `articles` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 1041: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 == 0)
{
echo "<br>Article ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$art = mysql_fetch_array( $check3 );
//-------------------------------
//article edits
//-------------------------------
if ($art['public'] != 1)
{
echo $skin['contentheader'];
echo $art['name'];
echo $skin['postcontentheader'];
echo $skin['contenttext'];
echo "This article is not yet available.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
echo $skin['postcontenttext'];
}
//-------------------------------
//cannot view article
//-------------------------------
else if ($mgroup['viewarticles'] != 1 AND $member['gid'] != $ra)
{
if ($art['guestredirect'] == 1)
{
echo "<SCRIPT language='JavaScript'>
<!--
window.location=" . $art['redirectto'] . ";
//-->
</SCRIPT>";
}
else
{
echo $skin['contentheader'];
echo $art['name'];
echo $skin['postcontentheader'];
echo $skin['contenttext'];
echo "Created By: " . $art['author'] . "<br>";
if (!$art['edit'])
{}
else
{
echo "Edited By: " . $art['edit'] . "<br>";
}
echo $art['guestview'];
echo $skin['postcontenttext'];
}
}
//-------------------------------
//member only article
//-------------------------------
else if ($art['memberonly'] == 1)
{
if ($cookie != 1)
{
if ($art['guestredirect'] == 1)
{
echo "<SCRIPT language='JavaScript'>
<!--
window.location=" . $art['redirectto'] . ";
//-->
</SCRIPT>";
}
else
{
echo $skin['contentheader'];
echo $art['name'];
echo $skin['postcontentheader'];
echo $skin['contenttext'];
echo "Created By: " . $art['author'] . "<br>";
if (!$art['edit'])
{}
else
{
echo "Edited By: " . $art['edit'] . "<br>";
}
echo $art['article'];
echo $skin['postcontenttext'];
}
}
else
{
echo $skin['contentheader'];
echo $art['name'];
echo $skin['postcontentheader'];
echo $skin['contenttext'];
echo "Created By: " . $art['author'] . "<br>";
if (!$art['edit'])
{}
else
{
echo "Edited By: " . $art['edit'] . "<br>";
}
echo $art['article'];
echo $skin['postcontenttext'];
}
}
//-------------------------------
//else
//-------------------------------
else
{
echo $skin['contentheader'];
echo $art['name'];
echo $skin['postcontentheader'];
echo $skin['contenttext'];
echo "Created By: " . $art['author'] . "<br>";
if (!$art['edit'])
{}
else
{
echo "Edited By: " . $art['edit'] . "<br>";
}
echo $art['article'];
echo $skin['postcontenttext'];
}
}
}
}
?>