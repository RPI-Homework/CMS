<?php
echo $skin['copyright'];
echo "&copy; 2007 <a href='http://computingonlinehelp.com/'>GiveMeHelp.net</a>";
echo $skin['footer'];
echo "</html>";
?>