<?php

//-------------------------------
//check for good cookie
//-------------------------------
if(isset($_COOKIE['admin_id']))
{
$check = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_COOKIE['admin_id'])or die("<br>Error Code 600: Please contact the Root Administrator immediately.<br>");
$num = mysql_num_rows($check);
if ($num == 0)
{
header("Location: " . $logout);
}
else
{
while($member = mysql_fetch_array( $check ))
{
$askin = $member['adminskin'];
global $askin;
$group_id = $member['gid'];
global $group_id;
$check2 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $member['gid'])or die("<br>Error Code 601: Please contact the Root Administrator immediately.<br>");
while($mgroup = mysql_fetch_array( $check2 ))
{
//-------------------------------
//cookie password match?
//-------------------------------
if ($_COOKIE['pass_hash'] != $member['password'])
{
header("Location: " . $logout);
}
//-------------------------------
//is admin?
//-------------------------------
else if ($mgroup['admin'] != 1 AND $member['gid'] != $ra)
{
echo "You are in a restricted area, <a href='" . $mdex ."'>click here</a> to leave.<br>";
}
else
{
$cookie = 1;
$admin_id = $_COOKIE['admin_id'];
$mq = "SELECT * FROM `users` WHERE `id` = " . $admin_id;
$gq = "SELECT * FROM `group` WHERE `id` = " . $group_id;
$ms = "SELECT * FROM `adminskin` WHERE `id` = " . $askin;
}
}
}
}
}
?>