<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 339: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
//-----------------
//by article name
//-----------------
if (isset($_GET['article']))
{
include $skincontent;
if (!$_GET['article'])
{
echo "<br>Error Code 63: No article name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `name` LIKE '%" . $_GET['article'] . "%' ORDER BY `name`")or die("<br>Error Code 340: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 64: No article names contains " . $_GET['article'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article names that contain " . $_GET['article'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Edit</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 341: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['author']))
{
include $skincontent;
if (!$_GET['author'])
{
echo "<br>Error Code 65: No author name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `author` LIKE '%" . $_GET['author'] . "%' ORDER BY `name`")or die("<br>Error Code 342: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 66: No article made by author " . $_GET['author'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article made by author " . $_GET['author'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Edit</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 343: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['editor']))
{
include $skincontent;
if (!$_GET['editor'])
{
echo "<br>Error Code 67: No editor name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `edit` LIKE '%" . $_GET['editor'] . "%' ORDER BY `name`")or die("<br>Error Code 344: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 68: No articles were edited by " . $_GET['editor'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Articles edited by " . $_GET['editor'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Edit</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 345: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['category']))
{
include $skincontent;
if (!$_GET['category'])
{
echo "<br>Error Code 69: Invalid category ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $_GET['category'])or die("<br>Error Code 346: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
echo "<br>Error Code 70: Invalid category ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$cedit = mysql_fetch_array( $check4 );
$check3 = mysql_query("SELECT * FROM `articles` WHERE `cat` = '" . $_GET['category'] . "' ORDER BY `name`")or die("<br>Error Code 347: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 71: No Article in category " . $cedit['name'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Article in category " . $cedit['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Edit</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name'] . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
echo "</table>";
}
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_GET['content']))
{
include $skincontent;
if (!$_GET['content'])
{
echo "<br>Error Code 72: No articles text enetered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `articles` WHERE `article` LIKE '%" . $_GET['article'] . "%' ORDER BY `name`")or die("<br>Error Code 348: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 73: No articles contain that text.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Searching by articles text.";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Author</center></td>
<td><center>Editor</center></td>
<td><center>Category</center></td>
<td><center>Member Only</center></td>
<td><center>Is Public</center></td>
<td><center>Edit</center></td>
</tr>";
while ($aedit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `acat` WHERE `id` = " . $aedit['cat'])or die("<br>Error Code 349: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check4);
if ($count == 0)
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>None</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
else
{
while ($cedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $aedit['name'] . "</center></td>
<td><center>" . $aedit['author'] . "</center></td>
<td><center>" . $aedit['edit'] . "</center></td>
<td><center>" . $cedit['name']    . "</center></td>
<td><center>";
if ($aedit['memberonly'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($aedit['public'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $aedit['id'] . "'>Edit</a></td>";
}
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
//-----------------
//search bars 0
//-----------------
else
{
include $skincontent;
echo $skins['contentheader'];
echo "Articles";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Search by Article Name.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='article'>
<input type='submit' name='name' value='Search' /></form>
Search by Author.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='author'>
<input type='submit' name='maker' value='Search' /></form>
Search by Editor.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='editor'>
<input type='submit' name='edit' value='Search' /></form>
Search by Category.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='category' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 350: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
Search by Article Content. Use % as a wildcard.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='content'>
<input type='submit' name='contains' value='Search' /></form>";
echo "<a href='listall.php'>List all Articles.</a>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
else
{
header("Location: " . $index);
}
}
?>