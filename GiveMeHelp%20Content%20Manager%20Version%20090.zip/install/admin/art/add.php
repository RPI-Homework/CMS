<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 297: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_POST['name']))
{
if (!$_POST['name'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 36: No article name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['author'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 37: No author name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['article'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 38: No article text entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_POST['guestredirect'] == 1 AND !$_POST['redirectto'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 39: A URL must be provided to use guest redirection.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$add = mysql_query("INSERT INTO `" . $database . "`.`articles` (
`id` ,
`name` ,
`author` ,
`edit` ,
`article` ,
`memberonly` ,
`guestredirect` ,
`redirectto` ,
`guestview` ,
`public` ,
`cat`
)
VALUES (
NULL ,
'" . $_POST['name'] . "',
'" . $_POST['author'] . "',
'" . $_POST['edit'] . "',
'" . $_POST['article'] . "',
'" . $_POST['memberonly'] . "',
'" . $_POST['guestredirect'] . "',
'" . $_POST['redirectto'] . "',
'" . $_POST['garticle'] . "',
'" . $_POST['public'] . "',
'" . $_POST['cat'] . "')")or die("<br>Error Code 298: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $articleindex);
}
}
}
}
}
else
{
//-------------------------------
//article edits
//-------------------------------
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Adding an Article";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$memcheck = mysql_query($mq)or die("<br>Error Code 299: Please contact the Root Administrator immediately.<br>");
$member = mysql_fetch_array( $memcheck );
$box = mysql_query("SELECT * FROM `acat` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 300: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Name</td><td><input type='text' name='name' value='" . $_POST['name'] . "'/></td></tr>
<tr><td>Author</td><td><input type='text' name='author' value='" . $member['user'] . "' /></td></tr>
<tr><td>Editor</td><td><input type='text' name='edit' value='" . $_POST['edit'] . "'/></td></tr>
<tr><td colspan='2'>Article<br><textarea rows='10' cols='75' name='article'>" . $_POST['article'] . "</textarea></td></tr>
<tr><td>Category</td><td><select name='cat'>
";
$num4 = mysql_num_rows($box);
if ($num4 == 0)
{
echo "<option value='0'>No Categories</option>";
echo "</select></td></tr>";
}
else
{
echo "<option value='0' selected='selected'>None</option>";
while($row = mysql_fetch_assoc($box))
{ 
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
}
echo "<tr><td>Available to Public</td><td>";
echo "Yes<input type='radio' name='public' value='1' checked='checked' />";
echo "No<input type='radio' name='public' value='0' /></td></tr>";
echo "<tr><td>Member Only Article<br>----If no fill out below</td><td>";
echo "Yes<input type='radio' name='memberonly' value='1' />";
echo "No<input type='radio' name='memberonly' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Guest Automatically Redirect</td><td>";
echo "Yes<input type='radio' name='guestredirect' value='1' />";
echo "No<input type='radio' name='guestredirect' value='0' checked='checked' /></td></tr>";
echo "<tr><td>Redirects to</td><td><input type='text' name='redirectto' value='" . $aedit['redirectto'] . "' /></td></tr>
<tr><td colspan='2'>Guest Article<br>----If guest redirect is no<br><textarea rows='10' cols='75' name='garticle'>" . $_POST['garticle'] . "</textarea></td></tr>
<tr><td colspan='2'><input type='submit' name='upart' value='Add Article' /></td></tr>
</table>
</form>";
include $skinfooter;
//-------------------
//End
//-------------------
}
}
}
?>