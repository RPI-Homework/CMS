<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 390: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
echo $skins['contentheader'];
echo "Member Groups";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add a Group<form action='add.php' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Add' />
</form>";
$gencheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 391: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_array( $gencheck );
$check = mysql_query($mq)or die("<br>Error Code 392: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 393: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
echo "Edit a Group<form action='edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 394: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option selected='selected' disabled='disabled'>Select a Group</option>";
while($row = mysql_fetch_assoc($box))
{
if ($member['gid'] == $ra)
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
else if ($row['id'] == $ra)
{

}
else if ($mgroup['addadmin'] != 1 AND $row['admin'] == 1)
{

}
else if ($row['id'] == $member['gid'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></form>";
$box2 = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 395: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "Delete a Group<form action='del.php' method='get'>
<select name='did' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Group</option>";
while($row = mysql_fetch_assoc($box2))
{
if ($row['id'] == $ra)
{

}
else if ($mgroup['addadmin'] != 1 AND $member['gid'] != $ra AND $row['admin'] == 1)
{

}
else if ($row['id'] == $member['gid'])
{

}
else if ($row['id'] == $gen['membergroup'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></form>";
echo $skins['postcontenttext'];
}
}
include $skinfooter;
//-------------------
//End
//-------------------
}
}
}
?>