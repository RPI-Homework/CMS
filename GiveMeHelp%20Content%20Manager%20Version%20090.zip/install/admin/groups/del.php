<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 366: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$gencheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 367: Please contact the Root Administrator immediately.<br>");
$gen = mysql_fetch_array( $gencheck );
$check = mysql_query($mq)or die("<br>Error Code 368: Please contact the Root Administrator immediately.<br>" . mysql_error());
$membe = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 369: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgrou = mysql_fetch_array( $check2 );
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_GET['did']))
{
if (!$_GET['did'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 78: Invalid group ID.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
$box2 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_GET['did'])or die("<br>Error Code 370: Please contact the Root Administrator immediately.<br>" . mysql_error());
$row = mysql_fetch_assoc($box2);
if ($_GET['did'] == $gen['membergroup'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 79: Cannot delete default Member group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_GET['did'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 80: Cannot delete Root Administrator group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($row['admin'] == 1 AND $mgrou['addadmin'] != 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 81: You cannot delete an Administrative group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_GET['did'] == $mgrou['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 82: Cannot delete your group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Deleteing " . $row['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'><table>
<tr><td>Move group users to</td><td colspan='2'><table>
<select name='mem'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 371: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($_GET['did'] == $row['id'])
{

}
else if ($gen['membergroup'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . "</option>";
}
else if ($membe['gid'] == $ra)
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
else if ($row['id'] == $ra)
{

}
else if ($mgrou['addadmin'] != 1 AND $row['admin'] == 1)
{

}
else if ($row['id'] == $membe['gid'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select>";
echo "</table></td></tr>
<tr><td>Are you sure?</td><td><table>
<input type='hidden' name='dddid' value='" . $_GET['did'] . "' />
<input type='submit' name='ddrid' value='Yes' /></form></table></td><td><table>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' /></form></table></td></tr></table></form>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
}
}
else if (isset($_POST['dddid']))
{
$yars = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '" . $_POST['mem'] . "' ORDER BY `name`")or die("<br>Error Code 372: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gup = mysql_fetch_array( $yars );
if ($_POST['dddid'] == $gen['membergroup'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 83: Cannot delete default Member group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_POST['dddid'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 84: Cannot delete Root Administrator group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($gup['admin'] == 1 AND $mgrou['addadmin'] != 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 85: You cannot delete an Administrative group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($_POST['dddid'] == $mgrou['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 86: Cannot delete your group.<br>
<a href='" . $groupsindex . "'>Back</a>";
include $skinfooter;
}
else
{
$update = mysql_query("UPDATE `" . $database . "`.`users` SET `gid` = '" . $_POST['mem'] . "' WHERE `users`.`gid` = " . $_POST['dddid'])or die("<br>Error Code 373: Please contact the Root Administrator immediately.<br>" . mysql_error());
$del = mysql_query("DELETE FROM `group` WHERE `group`.`id` = " . $_POST['dddid'] . " LIMIT 1")or die("<br>Error Code 374: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
}
}
}
}
else
{
header("Location: " . $groupsindex);
}
//-------------------
//End
//-------------------
}
}
?>