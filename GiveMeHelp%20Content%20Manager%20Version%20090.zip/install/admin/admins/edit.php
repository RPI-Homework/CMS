<?php
include "global.php";
include "../cookie.php";
if ($cookie == 1)
{
include "check.php";
if ($access == 1)
{
if (isset($_GET['id']))
{
if (!$_GET['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 27: No user ID.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 271: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
$check = mysql_query($mq)or die("<br>Error Code 272: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 273: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
//-------------------------------
//Rest of Page
//-------------------------------
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 274: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 == 0)
{
echo "<br>Error Code 28: User ID does not exist.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
else
{
while($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 275: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gedit = mysql_fetch_array( $check4 ))
{
//-------------------------------
//Admin no edit Root Admin
//-------------------------------
if ($medit['gid'] == $ra AND $member['gid'] != $ra)
{
echo "<br>Error Code 29: You cannot edit Root Administrators.<br>
<a href='" . $adminsindex . "'>Back</a>";
}
//-------------------------------
//Global Root admin edits
//-------------------------------
else if ($member['gid'] == $ra)
{
if ($medit['id'] != $member['id'])
{
echo $skins['contentheader'];
echo "Now editing " . $medit['user'] . ".";
echo $skins['postcontentheader'];
}
else
{
echo $skins['contentheader'];
echo "You are now editing Yourself.";
echo $skins['postcontentheader'];
}
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 276: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='id' value='" . $medit['id'] . "' />
<table border='0'><tr><td>Group</td><td><select name='group'>
";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'";
if ($medit['gid'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
if ($medit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' />";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' />";
}
echo "</td></tr><tr><td colspan='2'><center><input type='submit' name='Update' value='Update' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
//-------------------------------
//Admins editing admins
//-------------------------------
else if ($mgroup['addadmin'] == 1)
{
if ($medit['id'] == $member['id'])
{
echo "<br>Error Code 30: You cannot edit Yourself.<br>
<a href='" . $adminsindex . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Now editing " . $medit['user'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 277: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='id' value='" . $medit['id'] . "' />
<table border='0'><tr><td>Group</td><td><select name='group'>";
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $ra)
{

}
else
{
echo "<option value='" . $row['id'] . "'";
}
if ($medit['gid'] == $row['id'])
{
echo " selected='selected'";
}
echo ">" . $row['name'] . "</option>";
}
echo "</select></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
if ($medit['ban'] == 1)
{
echo "Yes<input type='radio' name='ban' value='1' checked='checked' />";
echo "No<input type='radio' name='ban' value='0' />";
}
else
{
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' />";
}
echo "</td></tr><tr><td colspan='2'><center><input type='submit' name='Update' value='Update' /></center></td></tr></table></form>";
echo $skins['postcontenttext'];
}
}
//-------------------------------
//Admins editing admins
//-------------------------------
else
{
echo "<br>Error Code 31: Unknown Error.<br>
<a href='" . $adminsindex . "'>Back</a>";
}
include $skinfooter;
}
}
}
}
}
}
}
//--------------------
//Submitted edit
//--------------------
else if (isset($_POST['Update']))
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 278: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$check = mysql_query($mq)or die("<br>Error Code 279: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 280: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($mgroup = mysql_fetch_array( $check2 ))
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_POST['id'])or die("<br>Error Code 281: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
while($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_POST['group'])or die("<br>Error Code 282: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gedit = mysql_fetch_array( $check4 ))
{
$check5 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 283: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($extra = mysql_fetch_array( $check5 ))
{
$theupdate = "UPDATE `" . $database . "`.`users` SET `gid` = " . $_POST['group'] . " WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1";
$banned2 = "UPDATE `" . $database . "`.`users` SET `ban` = " . $_POST['ban'] . " WHERE `users`.`id` = " . $_POST['id'] . " LIMIT 1";
if ($member['gid'] == $ra)
{
$update = mysql_query($theupdate)or die("<br>Error Code 284: Please contact the Root Administrator immediately.<br>" . mysql_error());
$update4 = mysql_query($banned2)or die("<br>Error Code 285: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $adminsindex);
}
else if ($medit['gid'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 32: You cannot edit Root Administrators.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
else if ($medit['id'] == $member['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 33: You cannot edit Yourself.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
else if ($gedit['id'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 34: You cannot create Root Administrators.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
else if ($mgroup['addadmin'] == 1)
{
$update = mysql_query($theupdate)or die("<br>Error Code 286: Please contact the Root Administrator immediately.<br>" . mysql_error());
$update4 = mysql_query($banned2)or die("<br>Error Code 287: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $adminsindex);
}
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 35: Unknown Error.<br>
<a href='" . $adminsindex . "'>Back</a>";
include $skinfooter;
}
}
}
}
}
}
}
else
{
header("Location: " . $adminsindex);
}
//-------------------
//End
//-------------------
}
else
{
header("Location: " . $index);
}
}
else
{
include "../login.php";
}
?>