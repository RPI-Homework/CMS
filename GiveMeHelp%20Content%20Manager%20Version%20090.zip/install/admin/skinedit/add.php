<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 514: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
if (isset($_POST['author']))
{
if (!$_POST['author'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 128: No author entered.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['skin'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 129: No skin name entered.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `adminskin` WHERE `skin` = '" . $_GET['add'] . "'")or die("<br>Error Code 515: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
if ($num2 != 0)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 130: A skin with that name already exists.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
$add = mysql_query("INSERT INTO `" . $database . "`.`adminskin` (`id` , `skin` , `author` , `header` , `banner` , `login` , `prelogin` , `prename` , `prelogout` , `postlogin` , `menu` , `menutitles` , `menulinks` , `postmenu` , `postmenulinks` , `betlinks` , `loginas` , `postloginas` , `content` , `contentheader` , `contenttext` , `postcontentheader` , `postcontenttext` , `copyright` , `footer` , `selectable` ) VALUES (NULL , '" . $_POST['skin'] . "', '" . $_POST['author'] . "', '" . $_POST['header'] . "', '" . $_POST['banner'] . "', '" . $_POST['login'] . "', '" . $_POST['prelogin'] . "', '" . $_POST['prename'] . "', '" . $_POST['prelogout'] . "', '" . $_POST['postlogin'] . "', '" . $_POST['menu'] . "', '" . $_POST['menutitles'] . "', '" . $_POST['menulinks'] . "', '" . $_POST['postmenu'] . "', '" . $_POST['postmenulinks'] . "', '" . $_POST['betlinks'] . "', '" . $_POST['loginas'] . "', '" . $_POST['postloginas'] . "', '" . $_POST['content'] . "', '" . $_POST['contentheader'] . "', '" . $_POST['contenttext'] . "', '" . $_POST['postcontentheader'] . "', '" . $_POST['postcontenttext'] . "', '" . $_POST['copyright'] . "', '" . $_POST['footer'] . "', '" . $_POST['selectable'] . "')")or die("<br>Error Code 516: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $skinindex);
}
}
}
}
else if (isset($_GET['add']))
{
if (!$_GET['add'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 131: No skin name entered.<br>
<a href='" . $skinindex . "'>Back</a>";
include $skinfooter;
}
else
{
include $skinheader;
include "../menu.php";
//-------------------------------
//Rest of Page
//-------------------------------


include $skincontent;
$check3 = mysql_query("SELECT * FROM `adminskin` WHERE `skin` = '" . $_GET['add'] . "'")or die("<br>Error Code 517: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
$gencheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 518: Please contact the Root Administrator immediately.<br>" . mysql_error());
if ($num2 != 0)
{
echo "<br>Error Code 132: A skin with that name already exists.<br>
<a href='" . $skinindex . "'>Back</a>";
}
else
{
while($gen = mysql_fetch_array( $gencheck ))
{
//-------------------------------
//Root Admin Edit
//-------------------------------
$check = mysql_query($mq)or die("<br>Error Code 519: Please contact the Root Administrator immediately.<br>");
while($member = mysql_fetch_array( $check ))
{
$check2 = mysql_query($gq)or die("<br>Error Code 520: Please contact the Root Administrator immediately.<br>");
while($mgroup = mysql_fetch_array( $check2 ))
{
echo $skins['contentheader'];
echo "Now adding skin " . $_GET['add'] . ".";
echo $skins['postcontentheader'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
echo $skins['contenttext'];
echo "<table><tr><td>Skin Name</td><td><input type='text' name='skin' value='" . $_GET['add'] . "' /></td></tr>
<tr><td>Author</td><td><input type='text' name='author'  value='" . $member['user'] . "' /></td></tr></table>";
echo "&lt;html&gt;<br>
&lt;title&gt;<br>
" . $gen['name'] . "<br>
&lt;/title&gt;<br>
&lt;head&gt;";
echo "
<textarea rows='6' cols='75' name='header'></textarea>
<br>
&lt;/head&gt;<br>
<textarea rows='6' cols='75' name='banner'></textarea><br>
------Below is excluded in the log in------
<br>
<textarea rows='6' cols='75' name='login'></textarea><br>
Log in Box
<br>
<textarea rows='3' cols='75' name='prelogin'></textarea><br>
Now Logged in as " . $mgroup['name'] . ":
<br>
<textarea rows='3' cols='75' name='prename'></textarea><br>
" . $member['user'] . "
<br>
<textarea rows='3' cols='75' name='prelogout'></textarea><br>
[Logout]
<br>
<textarea rows='3' cols='75' name='postlogin'></textarea><br>
<textarea rows='3' cols='75' name='menu'></textarea><br>
Menu Box
<br>
<textarea rows='3' cols='75' name='menutitles'></textarea><br>
[Menu Title]
<br>
<textarea rows='3' cols='75' name='postmenu'></textarea><br>
<textarea rows='3' cols='75' name='menulinks'></textarea><br>
[Menu Links]
<br>
<textarea rows='3' cols='75' name='betlinks'></textarea><br>
[Menu Links]
<br>
<textarea rows='3' cols='75' name='postmenulinks'></textarea><br>
<textarea rows='3' cols='75' name='loginas'></textarea><br>";
if ($member['gid'] == $ra)
{
echo "You are a Root Administrator.";
}
else
{
echo "You are an Administrator.";
}
echo "<br>
<textarea rows='3' cols='75' name='postloginas'></textarea><br>
------Above is excluded in the log in------
<br>
<textarea rows='6' cols='75' name='content'></textarea><br>
Content Box
<br>
<textarea rows='3' cols='75' name='contentheader'></textarea><br>
[Content Header]
<br>
<textarea rows='3' cols='75' name='postcontentheader'></textarea><br>
<textarea rows='3' cols='75' name='contenttext'></textarea><br>
[Content Body]
<br>
<textarea rows='3' cols='75' name='postcontenttext'></textarea><br>
<textarea rows='6' cols='75' name='copyright'></textarea><br>
[Copyright]
<br>
<textarea rows='6' cols='75' name='footer'></textarea><br>
&lt;/html&gt;";

echo "<dl><dt>Is the skin selectable?</dt>";
echo "<dd>Yes<input type='radio' name='selectable' value='1' checked='checked' />";
echo "No<input type='radio' name='selectable' value='0' /></dd></dl>";
echo"<input type='submit' value='Add Skin' />
</form>";

echo $skins['postcontenttext'];
}
}
}
}
include $skinfooter;
}
//-------------------
//End
//-------------------
}
else
{
header("Location: " . $skinindex);
}
}
}
else
{
header("Location: " . $index);
}
}
?>