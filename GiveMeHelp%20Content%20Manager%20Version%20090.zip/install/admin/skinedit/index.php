<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 540: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
echo $skins['contentheader'];
echo "Skins";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add an Administrative Skin<form action='add.php' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Add' />
</form>";
echo "Add a Member Skin<form action='madd.php' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Add' />
</form>";
echo "Edit an Administrative Skin<form action='edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 541: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 542: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gen = mysql_fetch_assoc($genset))
{
if ($row['id'] == $gen['adminskin'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
}
echo "</select></form>";
echo "Edit a Member Skin<form action='medit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option value='2' selected='selected' disabled='disabled'>Select a Skin</option>";
$box = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 543: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 544: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($gen = mysql_fetch_assoc($genset))
{
if ($row['id'] == $gen['skin'])
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
}
echo "</select></form>";
echo $skins['postcontenttext'];
}
}
include $skinfooter;
//-------------------
//End
//-------------------
}
?>