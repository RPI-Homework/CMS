<?php
include "global.php";
include "cookie.php";
if ($cookie != 1)
{
include "login.php";
}
else
{
include "gcheck.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
//Start 2
if (isset($_GET['alink']))
{
include $skinheader;
include "menu.php";
include $skincontent;
if (!$_GET['alink'])
{
echo "<br>Error Code 10: No link name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$skincheck = mysql_query($ms)or die("<br>Error Code 232: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo $skins['contentheader'];
echo "Adding Link " . $_GET['alink'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
Name</td><td><input type='text' name='alname' value='" . $_GET['alink'] ."'/></td></tr>
<tr><td>Link</td><td><input type='text' name='allink' size='75'/></td></tr>
<tr><td>Order</td><td><input type='text' name='alorder' maxlength='2' size='3'/></td></tr>
<tr><td>Category</td><td>
<select name='alcat'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 233: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
</td></tr>
<tr><td colspan='2'><input type='submit' name='aladd' value='Add Link'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else if (isset($_POST['aladd']))
{
if (!$_POST['alname'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 11: No link name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['alcat'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 12: No category ID entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$catcheck = mysql_query("SELECT * FROM `category` WHERE `id` = " . $_POST['alcat'])or die("<br>Error Code 234: Please contact the Root Administrator immediately.<br>");
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 13: Category does not exist.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$addlink = mysql_query("INSERT INTO `" . $database . "`.`menu` (`id` , `name` , `link` , `order` , `cat`)
VALUES (NULL , '" . $_POST['alname'] . "', '" . $_POST['allink'] . "', '" . $_POST['alorder'] . "', '" . $_POST['alcat'] . "')")or die("<br>Error Code 235: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
}
}
}
//-----------------
// 2
//-----------------
else if (isset($_GET['acat']))
{
include $skinheader;
include "menu.php";
include $skincontent;
if (!$_GET['acat'])
{
echo "<br>Error Code 14: No category name entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$skincheck = mysql_query($ms)or die("<br>Error Code 236: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo $skins['contentheader'];
echo "Adding Category " . $_GET['acat'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
Name</td><td><input type='text' name='aoname' value='" . $_GET['acat'] ."'/></td></tr>
<tr><td>Order</td><td><input type='text' name='aoorder' maxlength='2' size='3'/></td></tr>
<tr><td colspan='2'><input type='submit' name='aoadd' value='Add Category'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else if (isset($_POST['aoadd']))
{
if (!$_POST['aoname'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 15: No category name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$addcat = mysql_query("INSERT INTO `" . $database . "`.`category` (`id` , `name` , `order`)
VALUES (NULL , '" . $_POST['aoname'] . "', '" . $_POST['aoorder'] . "')")or die("<br>Error Code 237: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
}
//-----------------
// 2
//-----------------
else if (isset($_GET['elink']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 238: Please contact the Root Administrator immediately.<br>");
$linkcheck = mysql_query("SELECT * FROM `menu` WHERE `id` = " . $_GET['elink'])or die("<br>Error Code 239: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($linkcheck);
if ($num2 == 0)
{
echo "<br>Error Code 16: Link ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($link = mysql_fetch_array( $linkcheck ))
{
echo $skins['contentheader'];
echo "Editing Link " . $link['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
<input type='hidden' name='elid' value='" . $_GET['elink'] ."'/>
<tr><td>Name</td><td><input type='text' name='elname' value='" . $link['name'] ."'/></td></tr>
<tr><td>Link</td><td><input type='text' name='ellink' value='" . $link['link'] ."' size='75'/></td></tr>
<tr><td>Order</td><td><input type='text' name='elorder' value='" . $link['order'] ."' maxlength='2' size='3'/></td></tr>
<tr><td>Category</td><td>
<select name='elcat'>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 240: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $link['cat'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . " (Current)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>
<tr><td><input type='submit' name='eledit' value='Edit Link'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['eledit']))
{
if (!$_POST['elname'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 17: No link name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['elcat'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 18: No category ID entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$catcheck = mysql_query("SELECT * FROM `category` WHERE `id` = " . $_POST['elcat'])or die("<br>Error Code 241: Please contact the Root Administrator immediately.<br>");
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 19: Category does not exist.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$uplink = mysql_query("UPDATE `" . $database . "`.`menu` SET
`name` = '" . $_POST['elname'] . "',
`link` = '" . $_POST['ellink'] . "',
`order` = '" . $_POST['elorder'] . "',
`cat` = '" . $_POST['elcat'] . "' WHERE `menu`.`id` = " . $_POST['elid'] . " LIMIT 1")or die("<br>Error Code 242: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
}
}
}
//-----------------
// 2
//-----------------
else if (isset($_GET['ecat']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 259: Please contact the Root Administrator immediately.<br>");
$catcheck = mysql_query("SELECT * FROM `category` WHERE `id` = " . $_GET['ecat'])or die("<br>Error Code 243: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
echo "<br>Error Code 20: Category ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($cat = mysql_fetch_array( $catcheck ))
{
echo $skins['contentheader'];
echo "Editing Category " . $cat['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo"<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
<input type='hidden' name='ecid' value='" . $_GET['ecat'] ."'/>
Name</td><td><input type='text' name='ecname' value='" . $cat['name'] ."'/></td></tr>
<tr><td>Order</td><td><input type='text' name='ecorder' value='" . $cat['order'] ."' maxlength='2' size='3'/></td></tr>
<tr><td><input type='submit' name='ecedit' value='Edit Category'/>
</td></tr></table>
</form>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['ecedit']))
{
if (!$_POST['ecname'])
{
include $skinheader;
include "menu.php";
include $skincontent;
echo "<br>Error Code 21: No category name entered.<br>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$upcat = mysql_query("UPDATE `" . $database . "`.`category` SET
`name` = '" . $_POST['ecname'] . "',
`order` = '" . $_POST['ecorder'] . "' WHERE `category`.`id` = " . $_POST['ecid'] . " LIMIT 1")or die("<br>Error Code 244: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
}
//-----------------
// 2
//-----------------
else if (isset($_GET['olink']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 245: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo $skins['contentheader'];
echo "Ordering Link";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 246: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "
<table>";
while($row = mysql_fetch_assoc($box))
{
echo "<tr><td>" . $row['name'] . "</td><td></td><td></td><td></td></tr>";
$box2 = mysql_query("SELECT * FROM `menu` WHERE `cat` = '" . $row['id'] . "' ORDER BY `order`")or die("<br>Error Code 247: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row2 = mysql_fetch_assoc($box2))
{
echo "<tr><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'></td><td>" . $row2['name'] . "</td><td><table><input type='hidden' name='olid' value='" . $row2['id'] . "'><input type='text' name='olupdate' value='" . $row2['order'] . "' maxlength='2' size='3'/></table></td><td><table><input type='submit' name='olorder' value='Edit'></table></form></td></tr>";
}
}
echo "<tr><td colspan='4'><table><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='Finish'/></form></table></td></tr>
</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
else if (isset($_POST['olorder']))
{
$orderlink = mysql_query("UPDATE `" . $database . "`.`menu` SET `order` = '" . $_POST['olupdate'] . "' WHERE `menu`.`id` = " . $_POST['olid'] . " LIMIT 1")or die("<br>Error Code 232: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF'] . "?olink=true");
}
//-----------------
// 2
//-----------------
else if (isset($_GET['ocat']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 248: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skincheck );
echo $skins['contentheader'];
echo "Ordering Categories";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 249: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<table>";
while($row = mysql_fetch_assoc($box))
{
echo "<tr><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'></td><td>" . $row['name'] . "</td><td><table><input type='hidden' name='ocid' value='" . $row['id'] . "'><input type='text' name='ocupdate' value='" . $row['order'] . "' maxlength='2' size='3'/></table></td><td><table><input type='submit' name='ocorder' value='Edit'></table></form></td></tr>";
}
echo "<tr><td colspan='4'><table><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='Finish'/></form></table></td></tr>
</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
else if (isset($_POST['ocorder']))
{
$ordercat = mysql_query("UPDATE `" . $database . "`.`category` SET `order` = '" . $_POST['ocupdate'] . "' WHERE `category`.`id` = " . $_POST['ocid'] . " LIMIT 1")or die("<br>Error Code 250: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF'] . "?ocat=true");
}
//-----------------
// 2
//-----------------
else if (isset($_GET['dlink']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 251: Please contact the Root Administrator immediately.<br>");
$linkcheck = mysql_query("SELECT * FROM `menu` WHERE `id` = " . $_GET['dlink'])or die("<br>Error Code 252: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($linkcheck);
if ($num2 == 0)
{
echo "<br>Error Code 22: Link ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($link = mysql_fetch_array( $linkcheck ))
{
echo $skins['contentheader'];
echo "Deleting Link " . $link['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<table><tr><td valign='top'>
Are you sure?</td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='dlid' value='" . $_GET['dlink'] ."'/>
<input type='submit' name='dldel' value='Yes'/>
</form>
</td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No'/>
</form>
</td></tr></table>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['dldel']))
{
$dellink = mysql_query("DELETE FROM `menu` WHERE `menu`.`id` = " . $_POST['dlid'] . " LIMIT 1")or die("<br>Error Code 253: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
//-----------------
// 2
//-----------------
else if (isset($_GET['dcat']))
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 254: Please contact the Root Administrator immediately.<br>");
$catcheck = mysql_query("SELECT * FROM `category` WHERE `id` = " . $_GET['dcat'])or die("<br>Error Code 232: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
echo "<br>Error Code 23: Category ID does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($cat = mysql_fetch_array( $catcheck ))
{
echo $skins['contentheader'];
echo "Deleting Category " . $cat['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td valign='top'>
<input type='hidden' name='dcid' value='" . $_GET['dcat'] ."'/>
Category for Sub-Links</td><td colspan='2'>
<select name='dccat'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 255: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $cat['id'])
{

}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>
<tr><td valign='top'>Are you sure?</td><td>
<input type='submit' name='dcdel' value='Yes'/>
</form>
</td><td>
<table>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No'/>
</form>
</table>
</td></tr></table>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else if (isset($_POST['dcdel']))
{
if (!$_POST['dccat'])
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 256: Please contact the Root Administrator immediately.<br>");
$catcheck = mysql_query("SELECT * FROM `category` WHERE `id` = " . $_POST['dcid'])or die("<br>Error Code 257: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($catcheck);
if ($num2 == 0)
{
echo "<br>Error Code 24: That category does not exist.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
while($skins = mysql_fetch_array( $skincheck ))
{
while($cat = mysql_fetch_array( $catcheck ))
{
echo $skins['contentheader'];
echo "Deleting Category " . $cat['name'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table>
<input type='hidden' name='dcid' value='" . $_POST['dcid'] ."'/> 
<tr><td valign='top' width='40%'>No new category was selected. If yes is pressed, all links under this category will be deleted.</td><td width='5' valign='top'>
<input type='submit' name='dddddddddel' value='Yes'/>
</form>
</td><td valign='top' width='5'>
<table>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No'/>
</form>
</table>
</td><td></td></tr></table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
}
else
{
$uplink = mysql_query("UPDATE `" . $database . "`.`menu` SET `cat` = '" . $_POST['dccat'] . "' WHERE `menu`.`cat` = " . $_POST['dcid'])or die("<br>Error Code 258: Please contact the Root Administrator immediately.<br>");
$delcar = mysql_query("DELETE FROM `category` WHERE `category`.`id` = " . $_POST['dcid'] . " LIMIT 1")or die("<br>Error Code 259: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
}
else if (isset($_POST['dddddddddel']))
{
$dellink = mysql_query("DELETE FROM `menu` WHERE `menu`.`cat` = " . $_POST['dcid'])or die("<br>Error Code 260: Please contact the Root Administrator immediately.<br>");
$delcar = mysql_query("DELETE FROM `category` WHERE `category`.`id` = " . $_POST['dcid'] . " LIMIT 1")or die("<br>Error Code 261: Please contact the Root Administrator immediately.<br>");
header("Location: " . $_SERVER['PHP_SELF']);
}
//-----------------
// 2
//-----------------
else
{
include $skinheader;
include "menu.php";
include $skincontent;
$skincheck = mysql_query($ms)or die("<br>Error Code 262: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skincheck ))
{
echo "<table>";
echo "<tr><td colspan='2'>";
echo $skins['contentheader'];
echo "<center>Links</center>";
echo $skins['postcontentheader'];
echo "</td><td colspan='2'>";
echo $skins['contentheader'];
echo "<center>Categories</center>";
echo $skins['postcontentheader'];
echo "</td></tr>";
echo $skins['contenttext'];
echo "<tr><td valign='top'><center>Add a Link</center></td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<center>
<center><table><tr><td>
<input type='text' name='alink'/></td></tr><tr><td>
<div align='right'>
<input type='submit' name='add' value='Add Link'/>
</div>
</td></tr></table></center>
</center>
</form></td><td valign='top'><center>Add a Category</center></td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<center><table><tr><td>
<input type='text' name='acat'/></td></tr><tr><td>
<div align='right'>
<input type='submit' name='add' value='Add Category'/>
</div>
</td></tr></table></center>
</form></td></tr>
<tr><td valign='top'><center>Edit a Link</center></td><td>
<center>
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='elink' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Link</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 263: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option disabled='disabled'>" . $row['name'] . "</option>";
$box2 = mysql_query("SELECT * FROM `menu` WHERE `cat` = '" . $row['id'] . "' ORDER BY `order`")or die("<br>Error Code 264: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row2 = mysql_fetch_assoc($box2))
{
echo "<option value='" . $row2['id'] . "'>---" . $row2['name'] . "---</option>";
}
}
echo "</select></form>
</center>
</td><td valign='top'><center>Edit a Category</center></td><td><center>
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='ecat' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 265: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
</center></td></tr>
<tr><td valign='top'><center>Order Links</center></td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<center>
<input type='submit' name='olink' value='Order Links'/>
</center>
</form></td><td valign='top'><center>Order Categories</center></td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<center>
<input type='submit' name='ocat' value='Order Categories'/>
</center>
</form></td></tr>
<tr><td valign='top'><center>Delete a Link</center></td><td><center>
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='dlink' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Link</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 266: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option disabled='disabled'>" . $row['name'] . "</option>";
$box2 = mysql_query("SELECT * FROM `menu` WHERE `cat` = '" . $row['id'] . "' ORDER BY `order`")or die("<br>Error Code 267: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row2 = mysql_fetch_assoc($box2))
{
echo "<option value='" . $row2['id'] . "'>---" . $row2['name'] . "---</option>";
}
}
echo "</select></form>
</center></td><td valign='top'><center>Delete a Category</center></td><td><center>
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='dcat' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Category</option>";
$box = mysql_query("SELECT * FROM `category` WHERE `id` LIKE '%' ORDER BY `order`")or die("<br>Error Code 268: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>
</center></td></tr></table>";
echo $skins['postcontenttext'];
}
include $skinfooter;
}
//End 2
}
}
?>