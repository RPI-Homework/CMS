<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
include $skinheader;
include "../menu.php";
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 406: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$gencheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 407: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_array( $gencheck );
$check = mysql_query($mq)or die("<br>Error Code 408: Please contact the Root Administrator immediately.<br>" . mysql_error());
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 409: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
echo $skins['contentheader'];
echo "Homepages";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add a Homepage<form action='add.php' method='get'>
<input type='text' name='add' />
<input type='submit' name='submit' value='Add' />
</form>";
echo "Edit a Homepage<form action='edit.php' method='get'>
<select name='id' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Homepage</option>";
$box = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 410: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['title'];
if ($row['id'] == $gen['guesthome'])
{
echo " (Guest)";
}
if ($row['id'] == $gen['memberhome'])
{
echo " (Member)";
}
if ($row['id'] == $gen['staffhome'])
{
echo " (Staff)";
}
if ($row['id'] == $gen['adminhome'])
{
echo " (Admin)";
}
if ($row['id'] == $gen['banhome'])
{
echo " (Banned)";
}
echo "</option>";
}
echo "</select></form>";
echo "Delete a Homepage<form action='del.php' method='get'>
<select name='did' onChange = 'this.form.submit()'>";
echo "<option selected='selected' disabled='disabled'>Select a Homepage</option>";
$box2 = mysql_query("SELECT * FROM `homepage` WHERE `id` LIKE '%' ORDER BY `title`")or die("<br>Error Code 411: Please contact the Root Administrator immediately.<br>" . mysql_error());
while($row = mysql_fetch_assoc($box2))
{
if ($row['id'] == $gen['guesthome'] OR $row['id'] == $gen['memberhome'] OR $row['id'] == $gen['staffhome'] OR $row['id'] == $gen['adminhome'] OR $row['id'] == $gen['banhome'])
{}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['title'] . "</option>";
}
}
echo "</select></form>";
echo $skins['postcontenttext'];
include $skinfooter;
//-------------------
//End
//-------------------
}
}
?>