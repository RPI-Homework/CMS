<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
if (isset($_POST['ddid']))
{
$check = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 398: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_array( $check );
if ($_POST['ddid'] == $gen['guesthome'] OR $_POST['ddid'] == $gen['memberhome'] OR $_POST['ddid'] == $gen['staffhome'] OR $_POST['ddid'] == $gen['adminhome'] OR $_POST['ddid'] == $gen['banhome'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 93: You cannot delete a default homepage.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$delhome = mysql_query("DELETE FROM `homepage` WHERE `homepage`.`id` = " . $_POST['ddid'] . " LIMIT 1")or die("<br>Error Code 399: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $homeindex);
}
}
else if (isset($_GET['did']))
{
if (!$_GET['did'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 94: Invalid homepage ID.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$check = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_GET['did'])or die("<br>Error Code 400: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num = mysql_num_rows($check);
if ($num == 0)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 95: Invalid homepage ID.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$home = mysql_fetch_array( $check );
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 401: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
echo $skins['contentheader'];
echo "Deleting " . $home['title'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table><tr><td valign='top'>Are you sure?</td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='ddid' value='" . $_GET['did'] . "' />
<input type='submit' name='dddddho' value='Yes' />
</form></td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' />
</form></td></tr>
</table>
";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else
{
header("Location: " . $homeindex);
}
}
}
?>