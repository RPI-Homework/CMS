<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
if (isset($_POST['eid']))
{
$uphome = mysql_query("UPDATE `" . $database . "`.`homepage` SET `title` = '" . $_POST['title'] . "',
`content` = '" . $_POST['content'] . "' WHERE `homepage`.`id` = " . $_POST['eid'] . " LIMIT 1")or die("<br>Error Code 402: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $homeindex);
}
else if (isset($_GET['id']))
{
if (!$_GET['id'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 97: Invalid homepage ID.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$check = mysql_query("SELECT * FROM `homepage` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 403: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num = mysql_num_rows($check);
if ($num == 0)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 98: Invalid homepage ID.<br>
<a href='" . $homeindex . "'>Back</a>";
include $skinfooter;
}
else
{
$home = mysql_fetch_array( $check );
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 404: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
echo $skins['contentheader'];
echo "Editing " . $home['title'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table><tr><td>
Title</td><td>
<input type='text' name='title' value='" . $home['title'] . "' /></td></tr>
<tr><td>Content</td><td></td></tr>
<tr><td colspan='2'>
<textarea rows='10' cols='75' name='content'>" . $home['content'] . "</textarea>
</td></tr>
<tr><td colspan='2'>
<input type='hidden' name='eid' value='" . $_GET['id'] . "' />
<input type='submit' name='edit' value='Edit Homepage' />
</td></tr>
</table>
</form>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else
{
header("Location: " . $homeindex);
}
}
}
?>