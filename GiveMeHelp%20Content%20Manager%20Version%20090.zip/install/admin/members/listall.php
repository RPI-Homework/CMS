<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 511: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
include $skincontent;
echo $skins['contentheader'];
echo "Listing All Members";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>Ip Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Edit</center></td>
</tr>";
$check = mysql_query("SELECT * FROM `users` WHERE `user` LIKE '%'")or die("<br>Error Code 512: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($medit = mysql_fetch_array( $check ))
{
//-------------------------------
//list
//-------------------------------
$check2 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 513: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check2 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='edit.php?id=" . $medit['id'] . "'>Edit</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
include $skinfooter;
//-------------------
//End
//-------------------
}
}
else
{
header("Location: " . $index);
}
}
?>