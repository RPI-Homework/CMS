<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
if (isset($_POST['ip1']))
{
if (!$_POST['ip1'])
{
$_POST['ip1'] = "*";
}
if (!$_POST['ip2'])
{
$_POST['ip2'] = "*";
}
if (!$_POST['ip3'])
{
$_POST['ip3'] = "*";
}
if (!$_POST['ip4'])
{
$_POST['ip4'] = "*";
}
$ban = mysql_query("INSERT INTO `" . $database . "`.`ban` (
`id` ,
`ip`
)
VALUES (
NULL , '" . $_POST['ip1'] . "." . $_POST['ip2'] . "." . $_POST['ip3'] . "." . $_POST['ip4'] . "'
)")or die("<br>Error Code 436: Please contact the Root Administrator immediately.<br>" . mysql_error());

}
if (isset($_POST['del']))
{
$del = mysql_query("DELETE FROM `ban` WHERE `ban`.`id` = " . $_POST['del'] . " LIMIT 1")or die("<br>Error Code 437: Please contact the Root Administrator immediately.<br>" . mysql_error());
}
include $skinheader;
include "../menu.php";
$skinscheck = mysql_query($ms)or die("<br>Error Code 438: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
include $skincontent;
echo $skins['contentheader'];
echo "IP Ban";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Add an IP. Use * as a wildcard.
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='text' name='ip1' maxlength='3' size='3'> .
<input type='text' name='ip2' maxlength='3' size='3'> .
<input type='text' name='ip3' maxlength='3' size='3'> .
<input type='text' name='ip4' maxlength='3' size='3'>
<input type='submit' name='add' value='Add' /></form>
Delete an IP.
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<select name='del' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `ban` WHERE `id` LIKE '%' ORDER BY `ip`")or die("<br>Error Code 439: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option selected='selected' disabled='disabled'>Select an IP</option>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['ip'] . "</option>";
}
echo "</select></form>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
?>