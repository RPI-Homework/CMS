<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access == 1)
{
$mcheck = mysql_query($mq)or die("<br>Error Code 262: Please contact the Root Administrator immediately.<br>");
$memberss = mysql_fetch_array( $mcheck );
$gcheck = mysql_query($gq)or die("<br>Error Code 262: Please contact the Root Administrator immediately.<br>");
$groupss = mysql_fetch_array( $gcheck );
$skinscheck = mysql_query($ms)or die("<br>Error Code 262: Please contact the Root Administrator immediately.<br>");
while($skins = mysql_fetch_array( $skinscheck ))
{
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_GET['id']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['id'])
{
echo "<br>Error Code 105: Invalid member ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_GET['id'])or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 106: Invalid member ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$mdel = mysql_fetch_array( $check3 );
echo $skins['contentheader'];
echo "Now Deleteing" . $mdel['user'];
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table><tr><td valign='top'>Are you sure?</td><td><form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='hidden' name='did' value='" . $_GET['id'] . "' />
<input type='submit' name='dddid' value='Yes' /></form></td><td>
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<input type='submit' name='none' value='No' /></form></td></tr></table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
}
}
else if (isset($_POST['did']))
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `id` = " . $_POST['did'])or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mdel = mysql_fetch_array( $check3 );
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $mdel['gid'])or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gdel = mysql_fetch_array( $check4 );
if ($mdel['gid'] == $ra AND $memberss['gid'] != $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 107: You cannot delete Root Administrators.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
if ($gdel['admin'] == 1 AND $groupss['addadmin'] != 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo "<br>Error Code 108: You cannot delete Administrators.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
include $skinfooter;
}
else
{
$del = mysql_query("DELETE FROM `users` WHERE `users`.`id` = " . $_POST['did'] . " LIMIT 1")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $_SERVER['PHP_SELF']);
}
}
}
//-------------------------------
//listall
//-------------------------------
else if (isset($_GET['listall']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Listing All Members";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>Ip Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Delete</center></td>
</tr>";
$check = mysql_query("SELECT * FROM `users` WHERE `user` LIKE '%'")or die("<br>Error Code 229: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($medit = mysql_fetch_array( $check ))
{
$check2 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check2 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $medit['id'] . "'>Delete</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-----------------
//by username
//-----------------
else if (isset($_GET['user']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['user'])
{
echo "<br>Error Code 109: No username entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `user` LIKE '%" . $_GET['user'] . "%' ORDER BY `user`")or die("<br>Error Code 219: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 110: No usernames contain " . $_GET['user'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Usernames that contain " . $_GET['user'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>IP Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Delete</center></td>
</tr>";
while ($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 220: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $medit['id'] . "'>Delete</a></td>";
}
}
echo "</table>";
}
}
echo $skins['postcontenttext'];
include $skinfooter;
}
//-----------------
//by email 0
//-----------------
else if (isset($_GET['mail']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['mail'])
{
echo "<br>Error Code 111: No email address entered.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `email` LIKE '%" . $_GET['mail'] . "%' ORDER BY `user`")or die("<br>Error Code 221: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 112: No emails contain " . $_GET['mail'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "Emails that contain " . $_GET['mail'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>IP Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Delete</center></td>
</tr>";
while ($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 222: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $medit['id'] . "'>Delete</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
}
}
include $skinfooter;
}
//-----------------
//by ip 0
//-----------------
else if (isset($_GET['ips']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
if (!$_GET['ip1'])
{
$_GET['ip1'] = "%";
}
if (!$_GET['ip2'])
{
$_GET['ip2'] = "%";
}
if (!$_GET['ip3'])
{
$_GET['ip3'] = "%";
}
if (!$_GET['ip4'])
{
$_GET['ip4'] = "%";
}
$check3 = mysql_query("SELECT * FROM `users` WHERE `ip` LIKE '" . $_GET['ip1'] . "." . $_GET['ip2'] . "." . $_GET['ip3'] . "." . $_GET['ip4'] . "' ORDER BY `user`")or die("<br>Error Code 223: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 106: No IPs are " . $_GET['ip1'] . "." . $_GET['ip2'] . "." . $_GET['ip3'] . "." . $_GET['ip4'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "IPs that contain " . $_GET['ip1'] . "." . $_GET['ip2'] . "." . $_GET['ip3'] . "." . $_GET['ip4'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>IP Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Delete</center></td>
</tr>";
while ($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 224: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $medit['id'] . "'>Delete</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
}
include $skinfooter;
}
//-----------------
//by group 0
//-----------------
else if (isset($_GET['group']))
{
include $skinheader;
include "../menu.php";
include $skincontent;
$check5 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_GET['group'])or die("<br>Error Code 225: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check5);
if ($count == 0)
{
echo "<br>Error Code 113: Invalid group ID.<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
while ($extra = mysql_fetch_array( $check5 ))
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `gid` = " . $_GET['group'] . " ORDER BY `user`")or die("<br>Error Code 226: Please contact the Root Administrator immediately.<br>" . mysql_error());
$count = mysql_numrows($check3);
if ($count == 0)
{
echo "<br>Error Code 114: No users are in the group " . $extra['name'] . ".<br>
<a href='" . $_SERVER['PHP_SELF'] . "'>Back</a>";
}
else
{
echo $skins['contentheader'];
echo "User in group " . $extra['name'] . ".";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "<table border='1' rules='all' frame='void'>
<tr>
<td><center>Name</center></td>
<td><center>Group</center></td>
<td><center>Email</center></td>
<td><center>IP Address</center></td>
<td><center>Banned</center></td>
<td><center>Is Admin</center></td>
<td><center>Root Admin</center></td>
<td><center>Delete</center></td>
</tr>";
while ($medit = mysql_fetch_array( $check3 ))
{
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $medit['gid'])or die("<br>Error Code 227: Please contact the Root Administrator immediately.<br>" . mysql_error());
while ($gedit = mysql_fetch_array( $check4 ))
{
  echo "<tr>
<td><center>" . $medit['user'] . "</center></td>
<td><center>" . $gedit['name'] . "</center></td>
<td><center>" . $medit['email'] . "</center></td>
<td><center>" . $medit['ip']    . "</center></td>
<td><center>";
if ($medit['ban'] == 1 OR $gedit['ban'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($gedit['admin'] == 1)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><center>";
if ($medit['gid'] == $ra)
{
echo "Yes</center></td>";
}
else
{
echo "No</center></td>";
}
echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?id=" . $medit['id'] . "'>Delete</a></td>";
}
}
echo "</table>";
echo $skins['postcontenttext'];
}
}
}
include $skinfooter;
}
//-----------------
//search bars 0
//-----------------
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo $skins['contentheader'];
echo "Members";
echo $skins['postcontentheader'];
echo $skins['contenttext'];
echo "Search by Username.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='user'>
<input type='submit' name='name' value='Search' /></form>
Search by email.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='mail'>
<input type='submit' name='email' value='Search' /></form>
Search by ip. Use % as a wildcard.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<input type='text' name='ip1' maxlength='3' size='3'> .
<input type='text' name='ip2' maxlength='3' size='3'> .
<input type='text' name='ip3' maxlength='3' size='3'> .
<input type='text' name='ip4' maxlength='3' size='3'>
<input type='submit' name='ips' value='Search' /></form>
Search by group.
<form action='" . $_SERVER['PHP_SELF'] . "' method='get'>
<select name='group' onChange = 'this.form.submit()'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 230: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<option value='2' selected='selected' disabled='disabled'>Select a Group</option>";
while($row = mysql_fetch_assoc($box))
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
echo "</select></form>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "?listall=true'>List all Users.</a>";
echo $skins['postcontenttext'];
include $skinfooter;
}
//-------------------
//End
//-------------------
}
}
else
{
header("Location: " . $index);
}
}
?>