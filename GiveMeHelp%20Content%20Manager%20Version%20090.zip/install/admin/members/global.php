<?php
include "../../conf_global.php";
$logout = "../logout.php";
$index = "../index.php";
$membersindex = "index.php";
$listmembersindex = "listall.php";
$homeindex = "../home/index.php";
$articleindex = "../art/index.php";
$groupsindex = "../groups/index.php";
$adminsindex = "../admins/index.php";
$mdex = "../../index.php";
$skinindex = "../skinedit/index.php";
$setindex = "../general.php";
$menuindex = "../links.php";
$memarticleindex = "../art/member.php";
$delarticleindex = "../art/del.php";
$delgroupsindex = "../groups/del.php";
$delhomeindex = "../home/del.php";
$addmembersindex = "add.php";
$delmembersindex = "del.php";
$ipbanindex = "ban.php";
$delskinindex = "../skinedit/del.php";
$addarticleindex = "../art/add.php";
$catarticleindex = "../art/cat.php";
$skinheader = "../skin/header.php";
$skinmenu = "../skin/menu.php";
$skincontent = "../skin/content.php";
$skinfooter = "../skin/footer.php";
?>