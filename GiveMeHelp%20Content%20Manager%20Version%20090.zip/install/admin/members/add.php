<?php
include "global.php";
include "../cookie.php";
if ($cookie != 1)
{
include "../login.php";
}
else
{
include "check.php";
if ($access != 1)
{
header("Location: " . $index);
}
else
{
$skinscheck = mysql_query($ms)or die("<br>Error Code 412: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$check = mysql_query($mq)or die("<br>Error Code 413: Please contact the Root Administrator immediately.<br>" . mysql_error());
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 414: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
//-------------------------------
//Rest of Page
//-------------------------------
if (isset($_POST['Update']))
{
if (!$_POST['password'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 99: No password entered.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['name'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 100: No username entered.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
if (!$_POST['email'])
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 101: No email entered.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
$check3 = mysql_query("SELECT * FROM `users` WHERE `user` = '" . $_POST['name'] . "'")or die("<br>Error Code 415: Please contact the Root Administrator immediately.<br>" . mysql_error());
$num2 = mysql_num_rows($check3);
$check4 = mysql_query("SELECT * FROM `group` WHERE `id` = " . $_POST['group'])or die("<br>Error Code 416: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gedit = mysql_fetch_array( $check4 );
if ($num2 != 0)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 102: Username in use.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
if ($member['gid'] == $ra)
{
$addmember = mysql_query("INSERT INTO `" . $database . "`.`users` (
`id` ,
`user` ,
`gid` ,
`password` ,
`email` ,
`ip` ,
`ban` ,
`adminskin` ,
`skin` ,
`gender` ,
`canpm` ,
`editprofile` ,
`aim` ,
`msn` ,
`yim` ,
`icq` ,
`avatar` ,
`signature` ,
`interests` ,
`referal` ,
`birthday` ,
`url` ,
`location`
)
VALUES (
NULL ,
'" . $_POST['name'] . "',
'" . $_POST['group'] . "',
'" . md5($_POST['password']) . "',
'" . $_POST['email'] . "',
'0.0.0.0',
'" . $_POST['ban'] . "',
'" . $_POST['adminskin'] . "',
'" . $_POST['skin'] . "',
'" . $_POST['gender'] . "',
'" . $_POST['canpm'] . "',
'" . $_POST['editprofile'] . "',
'" . $_POST['aim'] . "',
'" . $_POST['msn'] . "',
'" . $_POST['yim'] . "',
'" . $_POST['icq'] . "',
'" . $_POST['avatar'] . "',
'" . $_POST['signature'] . "',
'" . $_POST['interests'] . "',
'" . $_POST['referal'] . "',
'" . $_POST['birthday'] . "',
'" . $_POST['url'] . "',
'" . $_POST['location'] . "'
)")or die("<br>Error Code 417: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
else if ($gedit['id'] == $ra)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 103: You cannot add a Root Administrator.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else if ($mgroup['addadmin'] == 1)
{
$addmember = mysql_query("INSERT INTO `" . $database . "`.`users` (
`id` ,
`user` ,
`gid` ,
`password` ,
`email` ,
`ip` ,
`ban` ,
`adminskin` ,
`skin` ,
`gender` ,
`canpm` ,
`editprofile` ,
`aim` ,
`msn` ,
`yim` ,
`icq` ,
`avatar` ,
`signature` ,
`interests` ,
`referal` ,
`birthday` ,
`url` ,
`location`
)
VALUES (
NULL ,
'" . $_POST['name'] . "',
'" . $_POST['group'] . "',
'" . md5($_POST['password']) . "',
'" . $_POST['email'] . "',
'0.0.0.0',
'" . $_POST['ban'] . "',
'" . $_POST['adminskin'] . "',
'" . $_POST['skin'] . "',
'" . $_POST['gender'] . "',
'" . $_POST['canpm'] . "',
'" . $_POST['editprofile'] . "',
'" . $_POST['aim'] . "',
'" . $_POST['msn'] . "',
'" . $_POST['yim'] . "',
'" . $_POST['icq'] . "',
'" . $_POST['avatar'] . "',
'" . $_POST['signature'] . "',
'" . $_POST['interests'] . "',
'" . $_POST['referal'] . "',
'" . $_POST['birthday'] . "',
'" . $_POST['url'] . "',
'" . $_POST['location'] . "'
)")or die("<br>Error Code 418: Please contact the Root Administrator immediately.<br>" . mysql_error());\
header("Location: " . $membersindex);
}
else if ($gedit['admin'] == 1)
{
include $skinheader;
include "../menu.php";
include $skincontent;
echo"<br>Error Code 104: You cannot add an Administrator.<br>
<a href='" . $membersindex . "'>Back</a>";
include $skinfooter;
}
else
{
$addmember = mysql_query("INSERT INTO `" . $database . "`.`users` (
`id` ,
`user` ,
`gid` ,
`password` ,
`email` ,
`ip` ,
`ban` ,
`adminskin` ,
`skin` ,
`gender` ,
`canpm` ,
`editprofile` ,
`aim` ,
`msn` ,
`yim` ,
`icq` ,
`avatar` ,
`signature` ,
`interests` ,
`referal` ,
`birthday` ,
`url` ,
`location`
)
VALUES (
NULL ,
'" . $_POST['name'] . "',
'" . $_POST['group'] . "',
'" . md5($_POST['password']) . "',
'" . $_POST['email'] . "',
'0.0.0.0',
'" . $_POST['ban'] . "',
'" . $_POST['adminskin'] . "',
'" . $_POST['skin'] . "',
'" . $_POST['gender'] . "',
'" . $_POST['canpm'] . "',
'" . $_POST['editprofile'] . "',
'" . $_POST['aim'] . "',
'" . $_POST['msn'] . "',
'" . $_POST['yim'] . "',
'" . $_POST['icq'] . "',
'" . $_POST['avatar'] . "',
'" . $_POST['signature'] . "',
'" . $_POST['interests'] . "',
'" . $_POST['referal'] . "',
'" . $_POST['birthday'] . "',
'" . $_POST['url'] . "',
'" . $_POST['location'] . "'
)")or die("<br>Error Code 419: Please contact the Root Administrator immediately.<br>" . mysql_error());
header("Location: " . $membersindex);
}
}
}
}
}
}
else
{
include $skinheader;
include "../menu.php";
include $skincontent;
$skinscheck = mysql_query($ms)or die("<br>Error Code 420: Please contact the Root Administrator immediately.<br>");
$skins = mysql_fetch_array( $skinscheck );
$check = mysql_query($mq)or die("<br>Error Code 421: Please contact the Root Administrator immediately.<br>" . mysql_error());
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 422: Please contact the Root Administrator immediately.<br>" . mysql_error());
$mgroup = mysql_fetch_array( $check2 );
//-------------------------------
//Admin no edit Root Admin
//-------------------------------
//-------------------------------
//Global Root admin edits
//-------------------------------
if ($member['gid'] == $ra)
{
echo $skins['contentheader'];
echo "Adding Member";
echo $skins['postcontentheader'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 423: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 424: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 425: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 426: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>
<tr><td>Group</td><td><select name='group'>
";
while($row = mysql_fetch_assoc($box))
{
if ($gen['membergroup'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their own profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Add Member' /></center></td></tr></table></form>";
}
//-------------------------------
//Admins editing admins
//-------------------------------
else if ($mgroup['addadmin'] == 1)
{
echo $skins['contentheader'];
echo "Adding Member";
echo $skins['postcontentheader'];
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 427: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 428: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 429: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 430: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
echo "
<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>
<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>";
echo "<tr><td>Group</td><td><select name='group'>";
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $ra)
{

}
else if ($gen['membergroup'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 431: Please contact the Root Administrator immediately.<br>" . mysql_error());
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their own profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Add Member' /></center></td></tr></table></form>";
}
//-------------------------------
//Other admin edits
//-------------------------------
else
{
echo $skins['contentheader'];
echo "Adding Member";
echo $skins['postcontentheader'];
echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
echo "<table border='0'>
<tr><td>Username</td><td><input type='text' maxlength='32' name='name' /></td></tr>
<tr><td>Password</td><td><input type='text' maxlength='32' name='password' /></td></tr>
<tr><td>Email Address</td><td><input type='text' name='email' /></td></tr>";
echo "<tr><td>Group</td><td><select name='group'>";
$box = mysql_query("SELECT * FROM `group` WHERE `id` LIKE '%' ORDER BY `name`")or die("<br>Error Code 432: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box2 = mysql_query("SELECT * FROM `adminskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 433: Please contact the Root Administrator immediately.<br>" . mysql_error());
$box3 = mysql_query("SELECT * FROM `memberskin` WHERE `id` LIKE '%' ORDER BY `skin`")or die("<br>Error Code 434: Please contact the Root Administrator immediately.<br>" . mysql_error());
$genset = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 435: Please contact the Root Administrator immediately.<br>" . mysql_error());
$gen = mysql_fetch_assoc($genset);
while($row = mysql_fetch_assoc($box))
{
if ($row['id'] == $ra OR $row['admin'] == 1)
{

}
else if ($gen['membergroup'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['name'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Administrative Panel Skin</td><td><select name='adminskin'>";
while($row = mysql_fetch_assoc($box2))
{
if ($gen['adminskin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Main Site Skin</td><td><select name='skin'>";
while($row = mysql_fetch_assoc($box3))
{
if ($gen['skin'] == $row['id'])
{
echo "<option value='" . $row['id'] . "' selected='selected'>" . $row['skin'] . " (Default)</option>";
}
else
{
echo "<option value='" . $row['id'] . "'>" . $row['skin'] . "</option>";
}
}
echo "</select></td></tr>";
echo "<tr><td>Gender</td><td>";
echo "Male<input type='radio' name='gender' value='1' checked='checked' />";
echo "Female<input type='radio' name='gender' value='0' /></td></tr>";
echo "<tr><td>Can send and recieve personal messages?</td><td>";
echo "Yes<input type='radio' name='canpm' value='1' checked='checked' />";
echo "No<input type='radio' name='canpm' value='0' /></td></tr>";
echo "<tr><td>Can edit their own profile?</td><td>";
echo "Yes<input type='radio' name='editprofile' value='1' checked='checked' />";
echo "No<input type='radio' name='editprofile' value='0' /></td></tr>";
echo "<tr><td>AIM</td><td><input type='text' name='aim' value='" . $medit['aim'] . "' /></td></tr>";
echo "<tr><td>MSN</td><td><input type='text' name='msn' value='" . $medit['msn'] . "' /></td></tr>";
echo "<tr><td>YIM</td><td><input type='text' name='yim' value='" . $medit['yim'] . "' /></td></tr>";
echo "<tr><td>ICQ</td><td><input type='text' name='icq' value='" . $medit['icq'] . "' /></td></tr>";
echo "<tr><td>URL</td><td><input type='text' name='url' value='" . $medit['url'] . "' /></td></tr>";
echo "<tr><td>Avatar</td><td><input type='text' name='avatar' value='" . $medit['avatar'] . "' /></td></tr>";
echo "<tr><td>Signature</td><td><textarea rows='3' cols='30' name='signature'>" . $medit['signature'] . "</textarea></td></tr>";
echo "<tr><td>Referal</td><td><input type='text' name='referal' value='" . $medit['referal'] . "' /></td></tr>";
echo "<tr><td>Birthday</td><td><input type='text' name='birthday' value='" . $medit['birthday'] . "' /></td></tr>";
echo "<tr><td>Location</td><td><input type='text' name='location' value='" . $medit['location'] . "' /></td></tr>";
echo "<tr><td>Interests</td><td><textarea rows='3' cols='30' name='interests'>" . $medit['interests'] . "</textarea></td></tr>";
echo "<tr><td>Is user banned?</td><td>";
if ($medit['ban'] == 1)
echo "Yes<input type='radio' name='ban' value='1' />";
echo "No<input type='radio' name='ban' value='0' checked='checked' /></td></tr>";
echo "<tr><td colspan='2'><center>";
echo "<input type='submit' name='Update' value='Add Member' /></center></td></tr></table></form>";
}
include $skinfooter;
}
}
//--------------------
//Submitted edit
//--------------------

//-------------------
//End
//-------------------
}
?>