<?php
if ($cookie == 1)
{
$check = mysql_query($mq)or die("<br>Error Code 604: Please contact the Root Administrator immediately.<br>");
$member = mysql_fetch_array( $check );
$check2 = mysql_query($gq)or die("<br>Error Code 605: Please contact the Root Administrator immediately.<br>");
$mgroup = mysql_fetch_array( $check2 );
if ($mgroup['caneditmembers'] == 1 OR $member['gid'] == $ra)
{
$maccess = 1;
}
if ($mgroup['editarticles'] == 1 OR $member['gid'] == $ra)
{
$aaccess = 1;
}
if ($mgroup['edithome'] == 1 OR $member['gid'] == $ra)
{
$haccess = 1;
}
if ($mgroup['addadmin'] == 1 OR $member['gid'] == $ra)
{
$adaccess = 1;
}
if ($mgroup['editgroups'] == 1 OR $member['gid'] == $ra)
{
$graccess = 1;
}
if ($mgroup['editskin'] == 1 OR $member['gid'] == $ra)
{
$saccess = 1;
}
}
?>