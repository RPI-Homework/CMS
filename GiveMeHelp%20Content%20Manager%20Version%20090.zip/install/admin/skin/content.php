<?php
if ($cookie == 1)
{
$skincheck = mysql_query($ms)or die("<br>Error Code 619: Please contact the Root Administrator immediately.<br>");

while($skin = mysql_fetch_array( $skincheck ))
{
echo $skin['content'];
}
}
else
{
$numcheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 620: Please contact the Root Administrator immediately.<br>");
while($genskin = mysql_fetch_array( $numcheck ))
{
$skincheck = mysql_query("SELECT * FROM `adminskin` WHERE `id` = " . $genskin['adminskin'])or die("<br>Error Code 621: Please contact the Root Administrator immediately.<br>");

while($skin = mysql_fetch_array( $skincheck ))
{
echo $skin['content'];
}
}
}
?>