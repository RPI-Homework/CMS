<?php
if ($cookie == 1)
{
$skincheck = mysql_query($ms)or die("<br>Error Code 625: Please contact the Root Administrator immediately.<br>");

while($skin = mysql_fetch_array( $skincheck ))
{
$numcheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 626: Please contact the Root Administrator immediately.<br>");
while($genskin = mysql_fetch_array( $numcheck ))
{
echo "<html>
<title>
" . $genskin['name'] . "
</title>
<head>
" . $skin['header'] . "
</head>
" . $skin['banner'] . "
";
}
}
}
else
{

$numcheck = mysql_query("SELECT * FROM `general` WHERE `id` = 1")or die("<br>Error Code 627: Please contact the Root Administrator immediately.<br>");
while($genskin = mysql_fetch_array( $numcheck ))
{
$skincheck = mysql_query("SELECT * FROM `adminskin` WHERE `id` = " . $genskin['adminskin'])or die("<br>Error Code 628: Please contact the Root Administrator immediately.<br>");

while($skin = mysql_fetch_array( $skincheck ))
{
echo "<html>
<title>
" . $genskin['name'] . "
</title>
<head>
" . $skin['header'] . "
</head>
" . $skin['banner'] . "
";
}
}
}
?>